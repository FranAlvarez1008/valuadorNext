<?php

require_once './api/Router.php';
require_once './api/api-controller.php';

//creamos el router
$router = new Router();

//definimos la tabla (  $router->addRoute(RECURSO, METODO, CLASSE, FUNCION)  )
$router->addRoute('props', 'GET', 'ApiController', 'getProps');
$router->addRoute('props-list', 'GET', 'ApiController', 'getPropsInterno');
$router->addRoute('partido', 'GET', 'ApiController', 'searchPartido');
$router->addRoute('location', 'GET', 'ApiController', 'searchLocation');
$router->addRoute('country', 'GET', 'ApiController', 'searchCountry');

// ruteo
$resource = $_GET['resource'];
$method = $_SERVER['REQUEST_METHOD'];
$router->route($resource, $method);