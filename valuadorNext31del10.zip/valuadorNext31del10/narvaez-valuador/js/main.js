"use strict"

const m2ratio = 50;
const API_URL = "api/";

let prop = []
let countryList = []
let _flagLote = false;

let select = document.querySelectorAll('select');
let button = document.querySelector('button');
let tipo = document.querySelector('#tipo');
let btnCountry = document.querySelector('#isCountry');
let barrio = document.querySelector('#barrio');
let countryBox = document.querySelector('#countryBox');
let boxLocalidad = document.querySelector('#boxLocalidad');
let partido = document.querySelector('#partido');
let otroCountry = document.querySelector('#otroCountry');
let boxBarrioSelector = document.querySelector('#nombreBarrio');
let boxLocalidadInput = document.querySelector('#localidadId');
let showBox = document.querySelector('#showBox');
let tasacion = document.querySelector('#tasacion');
let formData = document.querySelector('#form');
let boxRenderResult = document.querySelector('#boxRenderResult');
let errorMje = document.querySelector("#errorMje");
let telInput = document.querySelector("#tel");
let emailInput = document.querySelector("#email");
let switchCochera = document.querySelector('#cochera');
let switchPileta = document.querySelector('#pileta');
let switchParrilla = document.querySelector('#parrilla');
let m2cubInput = document.querySelector('#m2cub');
let ambientesInput = document.querySelector('#ambientes');
let habitacionesInput = document.querySelector('#habitaciones');
let cantidadInput = document.querySelector('#cantidad');

partido.addEventListener('change', getLocation);
tipo.addEventListener('change', loteInputsModifier);
btnCountry.addEventListener('click', habilitarBarrioSelect);


/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////// FRONT ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////


var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})

boxBarrioSelector.addEventListener('change', () => {
    if(boxBarrioSelector.value == 'otro')
        mostrarOtro(true)
    else
        mostrarOtro(false)
});

function habilitarBarrioSelect() 
{
    mostrarOtro(false)
    if (btnCountry.checked) {
        barrio.classList.remove('d-none');
        btnCountry.value = "on";
        boxBarrioSelector.setAttribute("required", true);
        listCountries();
    }
    else {
        btnCountry.value = null;
        barrio.classList.add('d-none');
        boxBarrioSelector.removeAttribute("required");
    }
}

function habilitarBarrio(flag) 
{
    if (flag) 
    {
        countryBox.classList.remove('d-none');
        countryBox.classList.remove('d-sm-none');
        btnCountry.value = null;
    }
    else 
    {
        countryBox.classList.add('d-none');
        countryBox.classList.add('d-sm-none');
        btnCountry.value = null;
    }
}

function loteInputsModifier()
{
    if(tipo.value == 'lote')
    {
        switchCochera.setAttribute('disabled', true);
        switchPileta.setAttribute('disabled', true);
        switchParrilla.setAttribute('disabled', true);
        m2cubInput.setAttribute('disabled', true);
        ambientesInput.setAttribute('disabled', true);
        habitacionesInput.setAttribute('disabled', true);
        cantidadInput.setAttribute('disabled', true);
        _flagLote = true;
    }
    else
    {
        _flagLote = false;
        switchCochera.removeAttribute('disabled', false);
        switchPileta.removeAttribute('disabled', false);
        switchParrilla.removeAttribute('disabled', false);
        m2cubInput.removeAttribute('disabled', false);
        ambientesInput.removeAttribute('disabled', false);
        habitacionesInput.removeAttribute('disabled', false);
        cantidadInput.removeAttribute('disabled', false);
    }
}

function mostrarOtro(show)
{
    if(show){
        otroCountry.classList.remove('d-none');
        otroCountry.classList.add('d-block');
        otroCountry.querySelector('input').setAttribute('required', true);
        if(screen.width > 576){
            barrio.classList.remove('col-sm-12')
            barrio.classList.add('col-sm-6');
            barrio.classList.add('col-xl-6');
            barrio.classList.add('col-lg-12');
        } 
    }else{
        otroCountry.classList.add('d-none');
        otroCountry.classList.remove('d-block');
        otroCountry.querySelector('input').removeAttribute("required");
        if(screen.width > 576){
            barrio.classList.add('col-sm-12')
            barrio.classList.remove('col-sm-6');
            barrio.classList.remove('col-xl-6');
            barrio.classList.remove('col-lg-12');
        } 
    }
}

async function listCountries()
{
    try {
        let partido_ = partido.value;
        let url_ = API_URL+'country?partido='+partido_;
        let response = await fetch(url_); 
        let data = await response.json();
        countryList = data;

        boxBarrioSelector.innerHTML = '<option value="" disabled selected>Seleccione Barrio</option>';
        let otro = "";
        data.forEach(element => {
            if(element['localidad']=='otro')
                otro = `<option style="font-weight: 600;" value="${element['localidad']}">${capitalizeName(element['localidad'])}</option>`;
            else
                boxBarrioSelector.innerHTML += `<option value="${element['id_country']}">${capitalizeName(element['localidad'])}</option>`
        });
        boxBarrioSelector.innerHTML += otro;
    } 
    catch(e) {
        console.log(e);
    }
}

function renderLocalidad(locations)
{
    boxLocalidadInput.innerHTML = '<option value="" disabled selected>Seleccione Localidad</option>';
    locations.forEach(location => {
        let str2 = capitalizeName(location['localidad'])
        if(location['localidad'] != 'barrio privado')
            boxLocalidadInput.innerHTML += `<option value="${location['id_location']}">${str2}</option>`
    });    
}

function capitalizeName(str)
{
    let arr = str.split(" ");
    for (var i = 0; i < arr.length; i++) {
        arr[i] = arr[i].charAt(0).toUpperCase() + arr[i].slice(1);
    }
    return arr.join(" ");
}

function showErroMje(flag)
{
    if (flag)
        errorMje.classList.remove('d-none');
    else
        errorMje.classList.add('d-none');
}

/* { Agregar nuevamente a LET PARTIDOS en caso de que lo requieran
    nombre: 'Capital Federal, CABA',
    value:'capital federal'
},
{
            nombre: 'Escobar, GBA Norte',
            value:'escobar'
        },
        {
            nombre: 'Pilar, GBA Norte',
            value:'pilar'
        },
       
        */

function selectPartido()
{
    let partidos=[
        {
            nombre: 'San Isidro, GBA Norte',
            value:'san isidro'
        },
        {
            nombre: 'San Fernando, GBA Norte',
            value:'san fernando'
        },
        {
            nombre: 'Tigre, GBA Norte',
            value:'tigre'
        },
        {
            nombre: 'Vicente López, GBA Norte',
            value:'vicente lópez'
        },
    ];
    partidos.forEach(parti => {
        partido.innerHTML += `<option value="${parti['value']}">${parti['nombre']}</option>` 
    });
}

function setMailTel()
{
    const params = new Proxy(new URLSearchParams(window.location.search), {
        get: (searchParams, prop) => searchParams.get(prop),
    });
    if(params.email != null){
        emailInput.value = (params.email);
        telInput.value = (params.tel);
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////// FUNCTIONALITY /////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

async function getLocation()
{
  try {
        if (partido.value == 'capital federal')
            habilitarBarrio(false);
        else{
            if (btnCountry.checked){
                btnCountry.checked = false;
                habilitarBarrio(false);
            }
            habilitarBarrioSelect()
            habilitarBarrio(true);
            mostrarOtro(false)
        }
        let partido_ = partido.value;
        let url_ = API_URL+'location?partido='+partido_;
        let response = await fetch(url_); 
        let data = await response.json();
        renderLocalidad(data)
  } 
  catch(e) {
      console.log(e);
  }
}

function sumBedRoom(){
    if(!_flagLote)
        cantidadInput.value = parseInt(cantidadInput.value) + 1;
}
function resBedRoom(){
    if(cantidadInput.value != 1 && !_flagLote)
        cantidadInput.value = parseInt(cantidadInput.value) - 1;
}

setMailTel();
selectPartido();
habilitarBarrio(false);
btnCountry.value = null;

