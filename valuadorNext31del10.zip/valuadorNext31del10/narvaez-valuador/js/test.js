function validarTelefono() {
    var telefono = document.getElementById("phoneInput").value;
    
    // Elimina los espacios en blanco de inicio y fin, si los hay
    telefono = telefono.trim();
  
    // Comprueba si la longitud del teléfono está entre 9 y 14 caracteres
    if (telefono.length >= 9 && telefono.length <= 14) {
      // El teléfono tiene una longitud válida
      console.log("El teléfono es válido.");
      document.getElementById("mensaje").innerHTML = "El teléfono es válido.";
    } else {
      // El teléfono no cumple con la longitud válida
       console.log("El teléfono no es válido.");
      document.getElementById("mensaje").innerHTML = "El teléfono NO es válido.";
    }
}

// Ejemplo de uso:
