$(document).scroll(function() {
  if (window.matchMedia("(max-width: 992px)").matches) {
    var y = $(this).scrollTop();
    if (y > 150) {
      $('.scrollable-menu').show();
      if ( $( '#collapseFilters' ).hasClass( "show" ) ) {
        $('.filters-overlay').fadeIn();
      }
    } else {
      $( "#collapseFilters" ).removeClass( "show" )
      $('.scrollable-menu').fadeOut();
      $('.filters-overlay').fadeOut();
    }
  }
});


$(document).ready(function() {
  $("#toFilters").click(function(event){
    $('html, body').animate({scrollTop: '+=151px'}, 1);
        //$('.filters-overlay').fadeOut();
      });

  $("#btn-filter-fixed").click(function(event){
    if ( $( '#collapseFilters' ).hasClass( "show" ) ) {
      $('.filters-overlay').fadeOut();
    }else{
      $('.filters-overlay').fadeIn();
    }
  });


//Ficha Carousel
var total = ($('#carouselProp .carousel-item').length);
$('#carouselProp .number').html('1/'+ total);

$('#carouselProp').on('slide.bs.carousel', function(e){
  $('#carouselProp .number').html(e.to+1+'/'+ total);
});
var totalVideos = ($('#carouselPropVideos .carousel-item').length);
$('#carouselPropVideos .number').html('1/'+ totalVideos);

$('#carouselPropVideos').on('slide.bs.carousel', function(e){
  $('#carouselPropVideos  .number').html(e.to+1+'/'+ totalVideos);
});

$("#fotosLauncher").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  $("#carouselProp").addClass('show-element');
});

$("#videosLauncher").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  $("#carouselPropVideos").addClass('show-element');
});

$("#matterportLauncher").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  $("#carouselProp360").addClass('show-element');
});

$("#mapLauncher").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  if($(this).closest('.ficha').hasClass('emprendimiento')) {}
  else {
    showMapView();
  }
  $("#carouselPropMap").addClass('show-element');
});

$("#fotosLauncherMob").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  $("#carouselProp").addClass('show-element');
});

$("#videosLauncherMob").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  $("#carouselPropVideos").addClass('show-element');
});

$("#matterportLauncherMob").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  $("#carouselProp360").addClass('show-element');
});

$("#mapLauncherMob").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  if($(this).closest('.ficha').hasClass('emprendimiento')) {}
  else {
    showMapView();
  }$("#carouselPropMap").addClass('show-element');
});
$("#streetViewLauncher").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  showStreetView();
  $("#carouselPropMap").addClass('show-element');
});

$("#streetViewLauncherMobile").click(function(event){
  $('.launcher').parent().removeClass('active');
  $(this).parent().addClass('active');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").addClass('hide-element');
  $("#carouselProp,#carouselPropVideos,#carouselPropPlano,#carouselPropMap,#carouselProp360").removeClass('show-element');
  showStreetView();
  $("#carouselPropMap").addClass('show-element');
});

});

//Hide/Show galleries on icon button click (FICHA)

var fotos = $("#carouselProp");
var videos = $("#carouselPropVideos");
var plano = $("#carouselPropPlano");
var mapa = $("#carouselPropMap");
var matterport = $("#carouselProp360");


// function fotosLauncher(){
//
//   fotos.removeClass( "hide-element" );
//   videos.removeClass( "show-element" );
//   mapa.removeClass( "show-element" );
//   matterport.removeClass( "show-element" );
// }
function videosLauncher(){
  fotos.addClass( "hide-element" );
  videos.addClass( "show-element" );
  mapa.removeClass( "show-element" );
  matterport.removeClass( "show-element" );
}
// function planoLauncher(){
// }
// function mapLauncher(){
//   fotos.addClass( "hide-element" );
//   videos.removeClass( "show-element" );
//   mapa.addClass( "show-element" );
//   matterport.removeClass( "show-element" );
// }

// function matterportLauncher(){
//   fotos.addClass( "hide-element" );
//   matterport.addClass( "show-element" );
//   videos.removeClass( "show-element" );
//   mapa.removeClass( "show-element" );
// }

//Contact Form


/* Sendmail */
var mail_sincro = false;

const url = window.location.search;
console.log("utm: ", window.location);
const urlParams = new URLSearchParams(url);
var utm_source = urlParams.get('utm_source');
var utm_medium = urlParams.get('utm_medium');
var utm_campaign = urlParams.get('utm_campaign');
var utm_content = urlParams.get('utm_content');
var utm_term = urlParams.get('utm_term');
var utm_id = urlParams.get('utm_id');

localStorage.setItem("utm_source", utm_source);
sessionStorage.setItem("utm_source", utm_source);


// Funcion para cerrar PopUp de agradecimiento
function cerrarPopupForm() {
    var popupForm = document.getElementById("popupForm");
    popupForm.style.display = "none";
}

// Formulario de contacto/tasacion/Propiedad y Emprendimiento
// ACÁ ABRE FUNCIÓN ENVIAR MAIL !!!!!
function enviar_mail(event,form)
{
  console.log(form.attr('id'));

  if (form[0].reportValidity()) {
    event.preventDefault();
    var datos = form.serializeObject();
	  console.log('form datos: ', datos);
    datos.tags = ["Web Narvaez"];
    if(datos.hasOwnProperty('extra_tags'))
      datos.tags.push(datos.extra_tags);
	if(datos.hasOwnProperty('ipInput'))
      datos.tags.push(datos.ip); 
	if(urlParams.has('utm_source'))
		datos.tags.push(utm_source);
	if(urlParams.has('utm_medium'))
		datos.tags.push(utm_medium);
	if(urlParams.has('utm_campaign'))
		datos.tags.push(utm_campaign);
	if(urlParams.has('utm_content'))
		datos.tags.push(utm_content);
	if(urlParams.has('utm_term'))
		datos.tags.push(utm_term);
	if(urlParams.has('utm_id'))
		datos.tags.push(utm_id);
	  
    if(datos.hasOwnProperty('divisionInput')){
      datos.inputText+= " <br>Localidad: " + datos.divisionInput;
    }
    if(datos.hasOwnProperty('addressInput')){
      datos.inputText+= " <br>Direccion: " + datos.addressInput;
    }
	datos.inputText+= "URL: " + window.location.search;

    if(mail_sincro){
      return false;
      console.log('sincro')
    }

  // Initiate Variables With Form Content
  if ($( "#selectPropType" ).val()) {
    var selectPropType = $( "#selectPropType option:selected" ).text();
    datos[ "tipoPropiedad" ] = selectPropType;
    datos.tags.push(selectPropType);
  }
  if ($( "#selectOperType" ).val()) {
    var selectOperType = $( "#selectOperType option:selected" ).text();
    datos[ "tipoOperacion" ] = selectOperType;
    datos.tags.push(selectOperType);
  }

  console.log('form datos: '+JSON.stringify(datos));

  var phone = $("#phoneInput").val();
  var name = $("#nameInput").val();
  var email = $("#emailInput").val();
  var message = $("#inputText").val();
  var ip = $("#ipInput").val();
  var phoneCheckbox = $("#phoneCheckbox");
  console.log(phone.length);
  if (phoneCheckbox.is(":checked")) {

    // Verifica si la longitud de phone está fuera del rango permitido
    if (phone.length < 10 || phone.length > 14) {
      // Muestra un mensaje de error en color rojo
      $("#phoneError").text("Ingrese un número de teléfono válido por favor").css("color", "red");

      // Evita el envío del formulario
      event.preventDefault();

      // Sal de la función
      return;
    } else {
      // Limpia el mensaje de error si el número es válido
      $("#phoneError").text("");
    }
  }

  // Verifica si el checkbox emailCheckbox está marcado
 var emailCheckbox = $("#emailCheckbox");
  if (emailCheckbox.is(":checked")) {


    // Utiliza una expresión regular para validar el formato del correo electrónico
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

    if (!emailPattern.test(email)) {
      // Muestra un mensaje de error en color rojo
      $("#emailError").text("Ingrese un correo electrónico válido por favor").css("color", "red");

      // Evita el envío del formulario
      event.preventDefault();

      // Sal de la función
      return;
    } else {
      // Limpia el mensaje de error si el correo es válido
      $("#emailError").text("");
    }
  }

  //var data = "nombre=" + name + "&email=" + email + "&telefono=" + phone + "&mensaje=" + message +"<br>"+ selectPropType;
  //console.log('form datos: '+JSON.stringify(data));
  if ($( "#emprendimiento_id" ).val() || $( "#propiedad_id" ).val() ) {
      var url = "../../../ajax/";
    }
    else {
    var url = "../ajax/";
  }
  mail_sincro = true;
  //envia el mail
  jqxhr = $.ajax({
    url:url,
    type: "POST",
    //data:data,
    data: datos,
    success: function(data){
      var respuesta = JSON.parse(data);
		console.log("Respuesta: ", respuesta);
      if (respuesta.status == 'OK') {
        if(respuesta.form_type == 'contacto'){
          dataLayer.push({
            'event':'form_contacto',
          });
        }
          if(respuesta.form_type == 'emprendimientos'){
          dataLayer.push({
            'event':'form_emprendimientos',
          });
        }
        if(respuesta.form_type == 'propiedades'){
          dataLayer.push({
            'event':'form_propiedades',
          });
        }
        if(respuesta.form_type == 'tasaciones'){
          dataLayer.push({
            'event':'form_tasaciones',
          });
        }
        if(respuesta.form_type == 'tasacion_online'){
          dataLayer.push({
            'event':'form_tasacion_online',
          });
        }
        form[0].reset();
        console.log('Exito, '+respuesta.message);

//PopUp de agradecimiento
    $('#popupThankYou').fadeIn('slow', function() {
      var popup = $(this);
      setTimeout(function() {
        popup.fadeOut('slow');
      }, 3000); // Mostrar durante 3 segundos
    });

      } else {
        console.log('Error, '+respuesta.message);
        //toastr.error('Error',respuesta.message);
      }

// Cierro popUp de agradecimiento
cerrarPopupForm()

    }
  });
  mail_sincro = false;

}

} // Aca cierra funcion enviar_mail

// devuelve el array serializado
$.fn.serializeObject = function()
{
  var o = {};
  var a = this.serializeArray();
  $.each(a, function() {
    if (o[this.name] !== undefined) {
      if (!o[this.name].push) {
        o[this.name] = [o[this.name]];
      }
      o[this.name].push(this.value || '');
    } else {
      o[this.name] = this.value || '';
    }
  });
  return o;
};

function doSearchProps(){

  //Init data dictionary with general parameters
  var data = {"current_localization_id":0,"current_localization_type":"division","price_from":0,"price_to":999999999,"operation_types":[1,2,3],"property_types":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25],"currency":"ANY","filters":[]};

  // Send data by GET to properties result page
  window.location='../propiedades/?order_by=price&limit=15&offset=15&order=desc&page=1&data='+JSON.stringify(data);
}