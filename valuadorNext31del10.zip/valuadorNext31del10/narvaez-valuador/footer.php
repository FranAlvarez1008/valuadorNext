<footer id="colophon" class="site-footer" role="contentinfo">
	
    <section class="footer text-center text-light position-relative pb-3">
        <div class="logo">
            <img src="./assets/narvaez-border.svg" alt="">
        </div>
        <div class="container-fluid px-sm-5 footer-inner">
            <div class="row contacto">
                <div class="col-12 direccion">
                    <p>Primera Junta 524 esq. Av. del Libertador, Buenos Aires, Argentina.</p>
                    <div class="phones">
                        <p class="mb-3"><a href="tel:1147342090"><img src="./assets/phone.svg" alt="telefono"> +54 11-4743-2090</a></p>
                        <p><a href="https://wa.me/5491128299141" target="_blank"><img src="./assets/whatsapp.svg" alt="whatsapp"> +54 9 11 2829-9141</a></p>
                    </div>
                </div>
            </div>
            <div class="row menu-footer justify-content-center">
                <div class="col-md-10">
                    <ul>
                        <li><a href='https://www.narvaez.com.ar/propiedades?order_by=id&order=DESC&limit=15&offset=15&data=%7B"current_localization_id"%3A0%2C"current_localization_type"%3A"division"%2C"price_from"%3A0%2C"price_to"%3A999999999%2C"operation_types"%3A%5B1%5D%2C"property_types"%3A%5B1%2C2%2C3%2C4%2C5%2C6%2C7%2C8%2C9%2C10%2C11%2C12%2C13%2C14%2C15%2C16%2C17%2C18%2C19%2C20%2C21%2C22%2C23%2C24%2C25%5D%2C"currency"%3A"ANY"%2C"filters"%3A%5B%5D%7D'>Venta</a></li>
                        <li><a href='https://www.narvaez.com.ar/propiedades?order_by=id&order=DESC&limit=15&offset=15&data=%7B"current_localization_id"%3A0%2C"current_localization_type"%3A"division"%2C"price_from"%3A0%2C"price_to"%3A999999999%2C"operation_types"%3A%5B2%5D%2C"property_types"%3A%5B1%2C2%2C3%2C4%2C5%2C6%2C7%2C8%2C9%2C10%2C11%2C12%2C13%2C14%2C15%2C16%2C17%2C18%2C19%2C20%2C21%2C22%2C23%2C24%2C25%5D%2C"currency"%3A"ANY"%2C"filters"%3A%5B%5D%7D'>Alquiler</a></li>
                        <li><a href="https://www.narvaez.com.ar/emprendimientos">Emprendimientos</a></li>
                        <li><a href="https://www.narvaez.com.ar/tasaciones">Tasaciones</a></li>
                        <li><a href="https://www.narvaez.com.ar/nosotros">Nosotros</a></li>
                        <li><a href="https://www.narvaez.com.ar/contacto">Contacto</a></li>
                    </ul>
                </div>
            </div>
            <div class="row social">
                <div class="col">
                    <a href="https://www.facebook.com/Narvaezinmobiliaria/" target="_blank" rel="noopener noreferrer"><img src="./assets/facebook.svg" alt="facebook">
                        <a href="https://www.instagram.com/inmobiliarianarvaez/" target="_blank" rel="noopener noreferrer"><img src="./assets/instagram.svg" alt="instagram"></a>
                        <a href="https://www.linkedin.com/company/narvaez/" target="_blank" rel="noopener noreferrer"><img src="./assets/linkedin.svg" alt="linkedin"></a>
                        <a href="https://www.youtube.com/channel/UC3jzA3ycrkaXG9eJJE8U78Q" target="_blank" rel="noopener noreferrer"><img src="./assets/youtube.svg" alt="youtube"></a>
                    </div>
                </div>

                <div class="developed">
                    <a>Desarrollado por HolaHello Studio - <?php echo(date("Y"))?></a>
                </div>
            </div>
        </section>
    </footer>

    <!-- 
        Scripts
    -->

    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>

<?php
    
    $route= $_SERVER['PHP_SELF'];
        $route = explode('/', $route);
        $route = $route[2];
        if($route == "index.php")
            echo('<script src="./js/main.js" type="text/javascript"></script>');
    
?>



</body>

</html>
