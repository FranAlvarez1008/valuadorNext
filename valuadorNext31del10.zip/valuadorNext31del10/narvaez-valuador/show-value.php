
<?php 
    // ob_start();

    // // Iniciar la sesión
    // session_start();

    // // // Acceder a los datos almacenados en las variables de sesión
    // $txt   = $_SESSION['txt'];
    // $value = $_SESSION['value'];
    // $email = $_SESSION['email'];
    // $tel   = $_SESSION['tel'];
    // // // Limpiar las variables de sesión si ya no se necesitan
    // unset($_SESSION['txt']);
    // unset($_SESSION['value']);
    // unset($_SESSION['email']);
    // unset($_SESSION['tel']);

    $txt = $_GET['txt'];
    $value = $_GET['value'];
    $email = $_GET['email'];
    $name = $_GET['name'];
    $lastname = $_GET['apellido'];
    $ip = $_GET['ipInput'];
    $tel = $_GET['tel'];
    if (isset($_GET['txt']))
        $txt = $_GET['txt'];
    else
        $txt = "";
    if (isset($_GET['ipInput']))
        $ip = $_GET['ipInput'];
    else
        $ip = "";
    if (isset($_GET['email']))
        $email = $_GET['email'];
    else
        $email = "";
    if (isset($_GET['tel']))
        $tel = $_GET['tel'];
    else
        $tel = "";
    if (isset($_GET['value']))
        $value = $_GET['value'];
    else
        $value = "";

    $msg = $txt."- Argentina. - Precio estimado: ".$value;

    
?>
    
    
    <!--
        header 
    -->

<?php 

    require_once './header.php'; 

?>

<script>

const apiUrl = 'https://api.clientify.net/v1/contacts/';
const apiKey = '250480051972986b4538c5a217919dca0ebda86b';

const data = {
    "email": '<?php echo $email  ?>',
    "description": '<?php echo $msg  ?>',
};
console.log(data);
const headers = {
    'Authorization': `Token ${apiKey}`,
    'Content-Type': 'application/json'
};

fetch(apiUrl, {
    method: 'POST',
    headers: headers,
    body: JSON.stringify(data)
})
.then(response => response.json())
.then(data => {
    console.log('Respuesta exitosa:', data);
})
.catch(error => {
    console.error('Error en la solicitud:', error);
});

</script>

    <img src="./assets/header_small_alta_2.jpg" class="img-header d-sm-none d-block" alt="precio a tu propiedad">
    <img src="./assets/header_desktop_2.jpg" class="d-sm-block d-none w-100" style="margin-top: 60px;"alt="precio a tu propiedad">


    <!--
        cuerpo 
    -->

    <div class="container-back-no-index">

        <div class="mx-auto container-white ps-1 pe-1">
            
            <div class="col-sm-12 pt-sm-4 pb-sm-4 pt-4 pb-5 mb-5" style="background-color: #777777;">
                <div class="mx-auto col-sm-6 col-12">
                    <h3 class="text-center" style="color: white;">El precio estimado es:</h3>
                    <h2 class="text-center"style="color: white;"><?php echo($value) ?></h2>
                    <p class="small-txt text-center mx-auto p-3 mb-0 pb-sm-0" style="color: white;"><?php echo($txt) ?> - Argentina.</p>
                </div>
            </div> 
            
            <div class="mx-auto body-width mb-5 mb-sm-5 ps-3 pe-3 ps-sm-0 pe-sm-0">

                <div class="me-4 col-sm-12">
                    <h4 >¿Te gustaría mejorar el precio?</h4>
                </div> 

                <div class="d-flex pt-3 mt-4 mb-4">
                    <div class="d-flex flex-direction-column justify-content-center">
                        <img src="./assets/icon2.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <h6 class="sm-col-9 small-txt ps-2 ps-md-4 pt-3">El rango de precio informado se obtiene comparando los parámetros de tu propiedad con nuestra base de datos.</h6>
                </div>

                <hr style="width: 100%;">

                <div class="d-flex mt-3 mb-3 ">
                    <div class="d-flex flex-direction-column justify-content-center">
                        <img src="./assets/icon4.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <h6 class="sm-col-9 small-txt ps-2 ps-md-4 mt-3 mb-3 mb-0">Para obtener un precio adecuado, es indispensable realizar una Tasación presencial con un profesional matriculado.</h6>
                </div>

                <hr style="width: 100%;">

                <div class="d-flex mt-3 mb-4">
                    <div class="d-flex flex-direction-column justify-content-center">
                        <img src="./assets/icon3.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <h6 class="sm-col-9 small-txt ps-2 ps-md-4 mt-3 mb-4" >El tasador asistirá a la propiedad y tomará en cuenta las características del inmueble: verificará los planos y titularidad del inmueble, su estado general, dimensiones de los ambientes, disposición interna, ubicación en el barrio, entre otras variables relevantes.</h6>
                </div>

                <div class="d-sm-flex justify-content-between align-center mt-5 mb-5 mb-sm-4 col-sm-12 col-12" style="margin-bottom: 30px !important;">
                    <form name="solicitar-tasacion" method="post" action="./thanks-contact.php?email=<?php echo($email)?>&tel=<?php echo($tel)?>&msg=<?php echo($msg)?>"  class="col-12 col-sm-6 small-txt ms-sm-1 mt-3 mt-sm-0">
                        <input type="hidden" id="name"   name="name"   value="<?php echo($name)?>">
                        <input type="hidden" id="lastname"     name="lastname"     value="<?php echo($lastname)?>"> 
                        <input type="hidden" id="ipInput"     name="ipInput"     value="<?php echo($ip)?>">   
                        <input type="hidden" id="email"   name="email"   value="<?php echo($email)?>">
                        <input type="hidden" id="tel"     name="tel"     value="<?php echo($tel)?>">
                        <input type="hidden" id="message" name="message" value="<?php echo($msg)?>">
                        <button type="submit" class="btn button-primary w-100 h-100 btn-heigth">SOLICITAR TASACIÓN</button>
                    </form>
                    <a type="button" class="btn btn-volver col-12 col-sm-6 small-txt ms-sm-1 mt-3 mt-sm-0 btn-heigth" href="/valuador/index.php?<?php echo('email='.$email.'&tel='.$tel)?>"><spam><img src="./assets/arrow.png" alt="" class="me-2" style="margin-bottom: 2px;"></spam>VOLVER A VALUAR</a>
                </div>
            
                <div class="mt-5 mb-5"></div>
            </div>

        </div>

    </div>

    <h6 class="legales p-4 pt-0 px-md-3 px-lg-5 mx-lg-2 " >LEGALES: La valuación online no reviste el carácter de tasación inmobiliaria. La información y los datos personales brindados por Ud., en forma voluntaria, serán almacenados por EXCHANGE SERVICES S. A. (en adelante “NARVAEZ”), con el único fin de mantenerse en contacto con Ud. y remitirle la información relacionada al servicio de valuación online.  NARVAEZ no utilizará esta información para finalidades distintas o incompatibles con aquellas que motivaron su obtención.</h6>
    
    <div class="mt-5 mb-5"></div>

    
<!-- 
    Footer 
-->

<?php 

    echo('<script type="text/javascript" src="https://api.clientify.net/web-marketing/webforms/external/script/138201.js"></script>');

    require_once('./footer.php'); 
   
    if($txt != ""){
        require_once('./to-clientify.php');
    
        require_once('./mailing/send-valuation.php');
    }


?>
