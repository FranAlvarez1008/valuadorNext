<?php
    ob_start();
    require_once('./obtain-query-string.php');
    require_once('./api/api-controller.php');
?>

<!-- 
    Procesa el pedido y busca resultados de la consutla
-->

<?php
$apiController = new ApiController();
$args = array(
    'id_loc'    => $localidad,
    'is_country' => $is_country,
    'id_country' => $country,
    'm2tot'     => $m2tot,
    'm2cub'     => $m2cub,
    'ratio_m2cub' => $m2cub,
    'ratio_m2tot' => $m2tot,
    'rooms'     => $rooms,
    'cant'      => $cant,
    'tipo'      => $tipo,
    'parking'   => $parking,
    'pool'      => $pool,
    'parrilla'  => $parrilla,
    'amenities' => '',
    'fullMeters' => ''
);

$props = $apiController->getProps($args);

// generating text response   
if ($tipo == 'casa')
    $txt = 'Casa con ';
elseif ($tipo == 'dpto')
    $txt = 'Departamento con ';
elseif ($tipo == 'ph')
    $txt = 'PH con ';
elseif ($tipo == 'lote')
    $txt = 'Lote con ';

if ($tipo == 'lote')
    $txt .= $m2tot . ' m2 totales, ';
else {
    $txt .= $cant . ' ';
    if ($rooms == 'true')
        $txt .= 'ambientes, ';
    else
        $txt .= 'dormitorios, ';

    $txt .= $m2cub . ' m2 cubiertos y ' . $m2tot . ' m2 totales, ';

    if ($parking == 'on' && $parrilla == 'on' && $pool == 'on')
        $txt .= 'con parrilla, pileta y estacionamiento, ';
    elseif ($parking == 'on' && $parrilla == 'on')
        $txt .= 'con parrilla y estacionamiento, ';
    elseif ($parrilla == 'on' && $pool == 'on')
        $txt .= 'con parrilla y pileta, ';
    elseif ($parking == 'on' && $pool == 'on')
        $txt .= 'con pileta y estacionamiento, ';
}

if ($tipo == 'casa')
    $txt .= 'ubicada en ' . $address . ', ';
else
    $txt .= 'ubicado en ' . $address . ', ';

if ($is_country == 'on') {
    $txt .= 'en el barrio privado de ';
    if ($country == 'otro')
        $txt .= ucwords($otroCountry) . ', ' . ucwords($partido) . '.';
    else {
        $modelCountry = new CountryModel();
        $countryName = $modelCountry->gerCountryById($country)->localidad;

        $txt .= ucwords($countryName) . ', ' . ucwords($partido) . '.';
    }
} else {
    $modelLocation = new LocationModel();
    $locName = $modelLocation->getLocationById($localidad)->localidad;
    $txt .= 'en ';
    $txt .= ucwords($locName) . ', ' . ucwords($partido) . '.';
}


// si no encuentra resultados /////////////////////////////////////////////////
if ($props['incidencias'] == 0) {

    // Envio de datos a show-results.php
    header("Location: no-results.php?txt=" . $txt . "&email=" . $email . "&tel=" . $tel . "&first_name=" . $name . "&last_name=" . $lastname . "&cargo=" . $ip);
    exit;

// si encuentra resultados ////////////////////////////////////////////////////
} else {

    $MIN_PRICE_RATIO = 0.4;
    $MAX_PRICE_RATIO = 0.6;

    // formato valor propiedad
    $valorMin = $props['value'] * $MIN_PRICE_RATIO;
    $valorMax = $props['value'] * $MAX_PRICE_RATIO;

    $valorMinRedondeado = ceil($valorMin / 1000) * 1000;
    $valorMaxRedondeado = ceil($valorMax / 1000) * 1000;

    $valorMinFormateado = 'U$D ' . number_format($valorMinRedondeado, 0, ',', '.');
    $valorMaxFormateado = 'U$D ' . number_format($valorMaxRedondeado, 0, ',', '.');

    $value = $valorMinFormateado . ' - ' . $valorMaxFormateado;

    // Envio de datos a show-value.php
    header("Location: show-value.php?txt=" . $txt . "&value=" . $value . "&email=" . $email . "&tel=" . $tel. "&first_name=" . $name . "&last_name=" . $lastname . "&cargo=" . $ip);
    exit;
}
?>