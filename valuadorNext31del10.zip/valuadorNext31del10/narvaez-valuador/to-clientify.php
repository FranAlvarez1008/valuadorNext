<?php
    
    $randomNumber = rand(10000, 99999);
    $addres_clientify = array(
        "street"    => "",
        "city"      => "", 
        "state"     => "", 
        "country"   => "", 
        "postal_code" => "", 
        "type"      => 1
    );

    $data_contact = array(
        'first_name'    => $name,
        'last_name'     => $lastname,
        'email'         => $email,
        'phone'         => $tel,
        'status'        => '',
        'title'         => $ip,
        'company'       => '',
        'contact_type'  => '',
        'contact_source'=> '',
        'addresses'     => array($addres_clientify),
        'custom_fields' => array(),
        'description'   => '',
        'remarks'       => '',
        'summary'       => '',
        'message'       => $msg,
        're_property_name' => '',
        'last_contact'  => null,
    );

    
    $response = postContact($data_contact);
   


    function postContact($data){
        $url = 'https://api.clientify.net/v1/contacts/';

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $headers = array(
            'Content-Type: application/json',
            'Authorization: Token 250480051972986b4538c5a217919dca0ebda86b'
        );

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        curl_close($ch);
        
        return json_encode($response);
    }

?>