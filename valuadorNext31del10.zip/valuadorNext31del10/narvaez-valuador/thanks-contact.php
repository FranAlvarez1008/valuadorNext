
    <?php 
    
        // require_once('./obtain-query-string.php'); 
        if (!isset($_POST['mail'])){
            if (isset($_GET['msg']))
                $msg = $_GET['msg'];
            else
                $msg = "";
            if (isset($_GET['tel']))
                $tel = $_GET['tel'];
            else
                $tel = "";
            if (isset($_GET['email']))
                $email = $_GET['email'];
            else
                $email = "";
            if (isset($_GET['name']))
                $name = $_GET['name'];
            else
                $name = "";
            if (isset($_GET['apellido']))
                $lastname = $_GET['apellido'];
            else
                $lastname = "";
        }

        // var_dump($tel." - ").$mail
        

    ?>
    
    <!-- 
        Header
    -->

    <?php require_once('./header.php'); ?>

    <img src="./assets/header_small_alta_2.jpg" class="img-header d-sm-none d-block" alt="precio a tu propiedad">
    <img src="./assets/header_desktop_2.jpg" class="d-sm-block d-none w-100" style="margin-top: 60px;"alt="precio a tu propiedad">

    <!-- 
        Form 
    -->

    <div class="container-back-no-index">
        <!-- <div class="mx-auto valuador-container p-4 mt-sm-1 mt-1 border-radius-5 "> -->
        <div class="mx-auto container-white p-4" style="margin-top:0px;">
            <div class="d-sm-flex flex-wrap mx-auto body-width">

            <div class="pt-3 mt-0 mt-sm-4 mb-3 col-12 col-sm-12">
                <div class="d-flex justify-content-center mb-3">
                    <img src="./assets/icon5.PNG" alt="" style="height: 40px;" class="mx-auto">
                </div>
                <h4 class="sm-col-12 ps-2 text-center">¡Recibimos tu solicitud de tasación!</h4>
            </div>

            <hr style="width: 100%;">

            <div class="pt-3 mt-3 mt-sm-1">
                <h6 class="sm-col-9 ps-2 small-txt mx-auto">Un agente se pondrá en contacto para coordinar una visita y tasar la propiedad. Por favor, chequeá tu cuenta <span class="text-danger font-weight-bolder"><?php echo($email) ?></span></h6>
                <h6 class="sm-col-9 ps-2 small-txt mx-auto">Si no lo encontrás, revisá la pestaña de Promociones o Spam.</h6>
            </div>


            <div class="d-sm-flex justify-content-between align-center mt-4 mb-3 col-sm-12 col-12">
                <a type="button" class="btn btn-volver col-12 col-sm-12 small-txt mt-1 mb-3 mt-sm-4 mb-sm-1 btn-heigth" href="/valuador/index.php?<?php echo('email='.$email.'&tel='.$tel)?>"><spam><img src="./assets/arrow.png" alt="" class="me-2" style="margin-bottom: 2px;"></spam>VOLVER A VALUAR</a>
            </div>
            
            <!-- <div class="d-block d-sm-none" style="height: 75px;"></div> -->
            
        </div>
        </div>
    </div>

    <h6 class="legales p-4 pt-0 px-md-3 px-lg-5 mx-lg-2 " >LEGALES: La valuación online no reviste el carácter de tasación inmobiliaria. La información y los datos personales brindados por Ud., en forma voluntaria, serán almacenados por EXCHANGE SERVICES S. A. (en adelante “NARVAEZ”), con el único fin de mantenerse en contacto con Ud. y remitirle la información relacionada al servicio de valuación online.  NARVAEZ no utilizará esta información para finalidades distintas o incompatibles con aquellas que motivaron su obtención.</h6>
    
    <div class="mt-5 mb-5"></div>
<!-- 
    Footer 
-->

    <?php 

        require_once('./footer.php'); 

        if (isset($_GET['msg'])) {
            $msg = $_GET['msg'];
        } else {
            $msg = "";
        }
        
        require_once('./mailing/request-valuation.php');
        
        require_once('./to-tokko.php');
        
    ?>