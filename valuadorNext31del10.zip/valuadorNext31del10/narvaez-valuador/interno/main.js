"use strict"

//const API_URL = "http://localhost/valuador/api/";
const API_URL = "https://www.narvaez.com.ar/valuador/api/";  // produccion

let prop = []
let countryList = []
const ORDEN = 1000;
const MIN_PRICE_RATIO = 0;
const MAX_PRICE_RATIO = 0.20;

let metaDataCasos = document.createElement('h5');
let metaDataRoundSearch = document.createElement('h5');
let dataBox = document.querySelector('#data');

let select = document.querySelectorAll('select');
let button = document.querySelector('button');
let tipo = document.querySelector('#tipo');
let btnCountry = document.querySelector('#barrioCerrado');
let barrio = document.querySelector('#barrio');
let countryBox = document.querySelector('#countryBox');
let boxLocalidad = document.querySelector('#boxLocalidad');

let localidad = document.querySelector('#localidad');
let otroCountry = document.querySelector('#otroCountry');
let boxBarrioSelector = document.querySelector('#nombreBarrio');
let boxLocalidad2 = document.querySelector('#localidad2');
let showBox = document.querySelector('#showBox');
let tasacion = document.querySelector('#tasacion');
let formData = document.querySelector('#form');
let boxRenderResult = document.querySelector('#boxRenderResult');

let switchCochera = document.querySelector('#cochera');
let switchPileta = document.querySelector('#pileta');
let switchParrilla = document.querySelector('#parrilla');
let m2cubInput = document.querySelector('#m2cub');
let ambientesInput = document.querySelector('#ambientes');
let habitacionesInput = document.querySelector('#habitaciones');
let cantidadInput = document.querySelector('#cantidad');

boxBarrioSelector.addEventListener('change', mostrarOtro);
localidad.addEventListener('change', getLocation);
tipo.addEventListener('change', loteInputsModifier);
btnCountry.addEventListener('click', habilitarBarrioSelect);


/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////// FRONT ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////



function habilitarBarrioSelect() {
    if (barrio.classList.contains('d-none')) {
        barrio.classList.remove('d-none');
        btnCountry.value = "on";
        listCountries();
    }
    else {
        btnCountry.value = null;
        barrio.classList.add('d-none');
    }
    boxLocalidad.classList.toggle('d-none');
}

function habilitarBarrio(flag) {
    if (flag) {
        countryBox.classList.remove('d-none');
        btnCountry.value = null;
    }
    else {
        countryBox.classList.add('d-none');
        btnCountry.value = null;
    }
}

function loteInputsModifier() {
    console.log(select.length);
    if (tipo.value == 'lote') {
        switchCochera.setAttribute('disabled', true);
        switchPileta.setAttribute('disabled', true);
        switchParrilla.setAttribute('disabled', true);
        m2cubInput.setAttribute('disabled', true);
        ambientesInput.setAttribute('disabled', true);
        habitacionesInput.setAttribute('disabled', true);
        cantidadInput.setAttribute('disabled', true);
    }
    else {

        switchCochera.removeAttribute('disabled', false);
        switchPileta.removeAttribute('disabled', false);
        switchParrilla.removeAttribute('disabled', false);
        m2cubInput.removeAttribute('disabled', false);
        ambientesInput.removeAttribute('disabled', false);
        habitacionesInput.removeAttribute('disabled', false);
        cantidadInput.removeAttribute('disabled', false);
    }

}

function mostrarOtro() {
    console.log(boxBarrioSelector.value);
    if (boxBarrioSelector.value == 'otro') {
        otroCountry.classList.remove('d-none');
        otroCountry.classList.add('d-block');
    } else {
        otroCountry.classList.add('d-none');
        otroCountry.classList.remove('d-block');
    }
}

async function listCountries() {
    try {
        let partido_ = localidad.value;
        let url_ = API_URL + 'country?partido=' + partido_;
        console.log(url_);
        let response = await fetch(url_);
        let data = await response.json();
        countryList = data;

        boxBarrioSelector.innerHTML = '<option value="none" disabled selected>Seleccione Barrio</option>';
        let otro = "";
        data.forEach(element => {
            if (element['localidad'] == 'otro')
                otro = `<option style="font-weight: 600;" value="${element['localidad']}">${capitalizeName(element['localidad'])}</option>`;
            else
                boxBarrioSelector.innerHTML += `<option value="${element['localidad']}">${capitalizeName(element['localidad'])}</option>`
        });
        boxBarrioSelector.innerHTML += otro;
    }
    catch (e) {
        console.log(e);
    }
}

function renderLocalidad(locations) {
    boxLocalidad2.innerHTML = '<option value="none" disabled selected>Seleccione Localidad</option>';
    locations.forEach(location => {
        let str2 = capitalizeName(location['localidad'])
        if (location['localidad'] != 'barrio privado')
            boxLocalidad2.innerHTML += `<option value="${location['id_location']}">${str2}</option>`
    });
}


function capitalizeName(str) {
    let arr = str.split(" ");
    for (var i = 0; i < arr.length; i++) {
        arr[i] = arr[i].charAt(0).toUpperCase() + arr[i].slice(1);
    }
    return arr.join(" ");
}

function selectPartido() {
    let partidos = [
        {
            nombre: 'Capital Federal, CABA',
            value: 'capital federal'
        },
        {
            nombre: 'Escobar, GBA Norte',
            value: 'escobar'
        },
        {
            nombre: 'Pilar, GBA Norte',
            value: 'pilar'
        },

        {
            nombre: 'San Isidro, GBA Norte',
            value: 'san isidro'
        },
        {
            nombre: 'San Fernando, GBA Norte',
            value: 'san fernando'
        },
        {
            nombre: 'Tigre, GBA Norte',
            value: 'tigre'
        },
        {
            nombre: 'Vicente López, GBA Norte',
            value: 'vicente lópez'
        },
    ];
    partidos.forEach(partido => {
        console.log(partido);
        localidad.innerHTML += `<option value="${partido['value']}">${partido['nombre']}</option>`
    });
}

function showResult(lista) {

    let table = `
    <table class="table">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Price</th>
          <th scope="col">Location</th>
          <th scope="col">Partido</th>
          <th scope="col">m2cub</th>
          <th scope="col">m2tot</th>
          <th scope="col">room</th>
          <th scope="col">bedr</th>
          <th scope="col">bath</th>
          <th scope="col">park</th>
          <th scope="col">parr</th>
          <th scope="col">pool</th>
          <th scope="col">cntry</th>
        </tr>
      </thead>
      <tbody>`;
    let count = 0
    // lista.sort((x, y) => x.price - y.price);
    lista.forEach(item => {
        console.log(lista);

        if ((item['url'] !== "/propiedades/casa-moderna-en-greenlands-en-venta-san-fernando-50852771.html") && (item['url'] !== "/propiedades/venta-casa-238-m-sup2--4-amb.-barrio-cerrado-50339988.html")){
            let price = Intl.NumberFormat('es-ES').format(item['price']);
            let parrilla = "";
            let pool = "";
            let cntry = "";
            count = count + 1
            if (item['parrilla'] == 1) { parrilla = "si" } else { parrilla = "no" };
            if (item['pool'] == 1) { pool = "si" } else { pool = "no" };
            if (item['is_country'] == 1) { cntry = "si" } else { cntry = "no" };
            table += `
            <tr>
            <th scope="row"><a href="https://zonaprop.com.ar${item['url']}" target="_blank">${count}</a></th>
            <td>U$S ${price}</td> <!-- Price -->
            <td>${item['location']}</td> <!-- Location -->
            <td>${item['partido']}</td> <!-- Partido -->
            <td>${item['m2cub']}</td> <!-- m2cub -->
            <td>${item['m2tot']}</td> <!-- m2tot -->
            <td>${item['rooms']}</td> <!-- room -->
            <td>${item['bedrooms']}</td> <!-- bedr -->
            <td>${item['bathrooms']}</td> <!-- bath -->
            <td>${item['parking']}</td> <!-- park -->
            <td>${parrilla}</td> <!-- parr -->
            <td>${pool}</td> <!-- pool -->
            <td>${cntry}</td> <!-- cntry -->
            </tr>`
        }
            
    });
    table += `</tbody></table>`;
    boxRenderResult.innerHTML = table
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////// FUNCTIONALITY /////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

function obtainFormData(event) {
    boxRenderResult.innerHTML = "";
    event.preventDefault();

    let details = {};
    let datos = new FormData(formData);
    console.log("datos", datos);
    // console.log(datos);

    details["localidad"] = datos.get("localidad2");
    details["tipo"] = datos.get("tipo");
    details["isCountry"] = btnCountry.value;
    details["cochera"] = datos.get("cochera");
    details["piletaHome"] = datos.get("pileta");
    details["rooms"] = null;
    details["bedrooms"] = null;
    details["cantidad"] = datos.get("cantidad");
    details["m2cub"] = datos.get("m2cub");
    details["m2tot"] = datos.get("m2tot");
    details["pileta"] = datos.get("piletaHome");
    details["parrilla"] = datos.get("parrilla");
    details["parkingDpto"] = datos.get("parkingDpto");
    details["barrio"] = datos.get("barrio");
    details["otroCountry"] = datos.get("otroCountry");


    if (details["isCountry"] == "on")
        countryList.forEach(country => {
            if (country['localidad'] == boxBarrioSelector.value)
                details["id_country"] = country['id_country'];
        });
    else

        if (datos.get("rooms") == 'rooms')
            details["rooms"] = true;
        else
            details["bedrooms"] = true;

    if (details["isCountry"] == "on")
        details['isCountry'] = 1;
    else
        details['isCountry'] = 0;

    // check empty fields
    if (details["localidad"] == null ||
        details["tipo"] == null ||
        details["m2tot"] == "" ||
        details["email"] == "" ||
        details["tel"] == "" ||
        details["address"] == "") {
        return;
    }
    else if (details["isCountry"] == 1 &&
        details["barrio"] == null) {
        return;
    }
    else if (details["isCountry"] == 1 &&
        boxBarrioSelector.value == 'otro' &&
        details["otroCountry"] == "") {
        return;
    }
    else if (details["tipo"] != 'lote' &&
        (details["m2cub"] == "" ||
            details["cantidad"] == "")) {
        return;
    }

    getProp(details)
    console.log(details);
}


async function getProp(details) {

    let str_params = stringParams(details)

    try {
        let url_ = API_URL + 'props-list' + str_params;
        console.log(url_)
        let response = await fetch(url_);
        let data = await response.json();
        console.log(data);
        // showValue(data, details);
        calculateValue(data);

    }
    catch (e) {
        console.log(e);
    }
}


function calculateValue(data) {
    dataBox.innerHTML = '';
    console.log(prop);
    prop = data['data'];
    let size = data['meta']['casos'];
    let roud_search = data['meta']['search_round'];

    // en caso de no encontrar resultados
    if (size == 0) {
        tasacion.innerHTML = "datos insuficientes";
        return;
    }
    else {
        metaDataCasos.classList.add('text-secondary');
        metaDataCasos.innerHTML = 'Cantidad de casos: '+size;
        metaDataRoundSearch.classList.add('text-secondary');
        metaDataRoundSearch.innerHTML = 'Tipo de búsqueda: ';
        if (roud_search == 1)
            metaDataRoundSearch.innerHTML += 'Conicidencia total';
        else if (roud_search == 2)
            metaDataRoundSearch.innerHTML += 'Se omiten Amenities';
        else
            metaDataRoundSearch.innerHTML += 'Se omiten Amenities y M2 cubiertos';
        dataBox.appendChild(document.createElement('hr'));
        dataBox.appendChild(metaDataCasos);
        dataBox.appendChild(metaDataRoundSearch);
        dataBox.appendChild(document.createElement('hr'));

    }
    // muestra el box de resultados
    if (showBox.classList.contains('d-none')) showBox.classList.remove('d-none');

    // calculo de promedio ponderado
    let sumMin = 0;
    let sumMax = 0;
    let countMin = 0;
    let countMax = 0;
    let middle = 0;
    let promPonderado = 0;

    // if 1 or 2 props results
    if (size == 1)
        promPonderado = parseInt(prop[0]['price']);
    else if (size == 2)
        promPonderado = (parseInt(prop[0]['price']) * 3 + parseInt(prop[1]['price']) * 7) / 10
    else {
        // calculate middle of the series
        if (size % 2 == 0)
            middle = size / 2
        else
            middle = Math.ceil(size / 2) - 1

        // ponderate average 70% - %30
        for (let index = 0; index < middle; index++) {
            sumMin += parseInt(prop[index]['price']);
            countMin += 1;
        }
        for (let index = middle; index < size; index++) {
            sumMax += parseInt(prop[index]['price']);
            countMax += 1;
        }
        let promMin = sumMin / countMin;
        let promMax = sumMax / countMax;
        promPonderado = (promMax * 6 + promMin * 4) / 10;
        console.log(promPonderado);
    }

    // preparando rango de valores a mostrar
    let resultMin = Intl.NumberFormat('es-ES').format(redondearHaciaArriba(promPonderado - promPonderado * MIN_PRICE_RATIO));
    let resultMax = Intl.NumberFormat('es-ES').format(redondearHaciaArriba(promPonderado + promPonderado * MAX_PRICE_RATIO));

    tasacion.innerHTML = "U$S " + resultMin + " - U$S " + resultMax;

    showResult(prop)
}

function redondearHaciaArriba(numero) {
    return Math.ceil(numero / ORDEN) * ORDEN;
}

async function getLocation() {
    try {
        console.log(localidad.value);
        if (localidad.value == 'capital federal')
            habilitarBarrio(false);
        else
            habilitarBarrio(true);


        let partido_ = localidad.value;
        let url_ = API_URL + 'location?partido=' + partido_;
        console.log(url_);
        let response = await fetch(url_);
        let data = await response.json();
        renderLocalidad(data)
    }
    catch (e) {
        console.log(e);
    }
}

function stringParams(details) {
    let str = '?id_loc=' + details['localidad'] +
        '&localidad=' + boxLocalidad2.options[boxLocalidad2.selectedIndex].text +
        '&tipo=' + details["tipo"] +
        '&is_country=' + details["isCountry"] +
        '&id_country=' + details['id_country'] +
        '&m2tot=' + details["m2tot"] +
        '&m2cub=' + details["m2cub"] +
        '&rooms=' + details["rooms"] +
        '&bedrooms=' + details["bedrooms"] +
        '&cant=' + details["cantidad"] +
        '&partido=' + localidad.value +
        '&parrilla=' + details['parrilla'] +
        '&pool=' + details['pileta'] +
        '&parking=' + details["cochera"] +
        '&email=' + details["email"] +
        '&tel=' + details["tel"] +
        '&new_country=' + details["otroCountry"] +
        '&country=' + boxBarrioSelector.options[boxBarrioSelector.selectedIndex].text +
        '&address=' + details["address"]
        ;
    return str;
}

selectPartido();
habilitarBarrio(false);
btnCountry.value = null;
