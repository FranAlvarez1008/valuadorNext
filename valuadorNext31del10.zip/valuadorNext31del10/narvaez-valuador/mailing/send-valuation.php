<?php

    require_once './mailing/send_mail.php';
    // $from = 'tomas@holahellostudio.com';
    $from = 'recepcion@narvaez.com.ar';

    $mailSender = new SendEmail($from);

    // require_once './mailing/send_mail.php';
    // $from = 'tomas@holahellostudio.com';
    // $mailSender = new SendEmail($from);

	$subject = "Valuación Online - Narvaez Inmobiliaria";
	$to = $email;

	$message ="
    <head>
        <meta charset='UTF-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>MailContent</title>
        <!-- <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet'
        integrity='sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC' crossorigin='anonymous'> -->
        <link href='https://fonts.cdnfonts.com/css/avenir' rel='stylesheet'>
    </head>
    
    <div style='background: rgb(207, 207, 207); padding-bottom: 6px; padding-top: 6px;'>
        
    <div  style='
            margin-right: auto; 
            margin-left: auto; 
            max-width: 575px;
            '>

            <div style='text-align: center; padding: 5px; background-color: #ffffff;'>
				<img src='https://www.narvaez.com.ar/valuador/assets/narvaez-border_02.png' alt='narvaez inmobiliaria logo'
                style='height: 48px;'>
			</div>
            <img src='https://www.narvaez.com.ar/valuador/assets/header_mail_2.png' alt='precio a tu propiedad'
            style='
                margin-right: auto; 
                margin-left: auto;
                width: 100%'>

			<div style='
                        background-color: #ffffff;  
                        padding-top: 15px; 
                        padding-bottom: 10px;
                        padding-right: 10px;
                        padding-left: 10px;
                        margin-bottom: 5px;


                        '>
					<h3 style='text-align: center; color: rgb(0, 0, 0);font-family:sans-serif !important;'>El valor estimado es:</h3>
					<h2 style='text-align: center; color: rgb(0, 0, 0); font-family:sans-serif !important;'>"; $message .= $value; $message .= "</h2>
					<p style='padding-left: 5px; padding-right: 5px; text-align: center; color:rgb(0, 0, 0);font-family:sans-serif !important;'>"; $message .= $txt; $message .= ", Argentina.</p>
			</div> 

			<div style='background-color: white; 
                        margin-right: auto; 
                        margin-left: auto;  
                        max-width: 575px; 
                        padding-bottom: 30px;
                        padding-left: 10px;
						padding-right: 10px;
                        '>

				
				<div style='padding-left: 5px; padding-right: 5px;'>

                    <div style='padding-top:10px; padding-left: 5px'>
                        <h3 style='font-family:sans-serif;'>¿Te gustaría mejorar el precio?</h3>
                    </div> 

                    <div style='
                                display: flex;
                                padding-top: 5px;
                                margin-bottom: 8px;
                            '   >
                        <img src='https://www.narvaez.com.ar/valuador/assets/icon2.PNG' alt='' style='height: 40px; margin-top: auto; margin-bottom: auto; margin-right: 8px;'>
                        <h5 style='font-family:sans-serif !important; font-size: 12px; font-weight: 100;'>Para obtener un precio adecuado, es indispensable realizar una Tasación presencial con un profesional matriculado.</h5>
                    </div>

                    <hr style='width: 100%; color: #e8e7e7; border: solid 1px;'>

                    <div style='
                                display: flex;
                                padding-top: 5px;
                                margin-bottom: 8px;
                            '   >
                        <img src='https://www.narvaez.com.ar/valuador/assets/icon4.PNG' alt='' style='height: 40px; margin-top: auto; margin-bottom: auto; margin-right: 8px;'>
                        <h5 style='font-family:sans-serif !important; font-size: 12px; font-weight: 100;'>El tasador asistirá a la propiedad y tomará en cuenta las características del inmueble: verificará los planos y titularidad del inmueble, su estado general, dimensiones de los ambientes, disposición interna, ubicación en el barrio, entre otras variables relevantes.</h5>
                    </div>

                    <hr style='width: 100%; color: #e8e7e7; border: solid 1px;'>

                    <div style='
                                display: flex;
                                padding-top: 5px;
                                margin-bottom: 15px;
                            '   >
                        <img src='https://www.narvaez.com.ar/valuador/assets/icon3.PNG' alt='' style='height: 40px; margin-top: auto; margin-bottom: auto; margin-right: 8px;'>
                        <h5 style='font-family:sans-serif !important; font-size: 12px; font-weight: 100;'>En caso de solicitarlo, nuestro agente inmobiliario visitará la propiedad, y tomará en cuenta todas las características propias del inmueble, del barrio y del mercado, antes de presentarte el valor de tasación más acertado.</h5>
                    </div>

                    <div style='text-align: center;'>
                        <a type='button' style='
                                margin-top: 15px;
                                margin-bottom: 15px;
                                padding-top: 14px;
                                padding-bottom: 14px;
                                padding-left: 40px;
                                padding-right: 40px;
                                background-color: #C62C2C;
                                appearance: button;
                                color: white;
                                text-decoration: none;
                                font-family:sans-serif;
                                text-align: center;
                                font-size: 14px;
                                font-weight: 800;
                                letter-spacing: 3px;
            
                                '
                        href='https://www.narvaez.com.ar/valuador/thanks-contact.php?email="; $message .= $email; $message .="&tel=".$tel."&msg=".$msg; $message .="'>SOLICITAR TASACIÓN</a>
                    </div>

                </div>
            
            </div>

			<div style='background-color: white; 
						margin-right: auto; 
						margin-left: auto; 
						margin-top: 5px; 
						max-width: 575px;
						padding-bottom:20px'>
				<div style='padding-left: 10px; padding-right: 10px;'>
					<div style='
								padding-top: 5px;
								margin-bottom: 8px;
							'   >
                        <h6 style='font-family:sans-serif !important; font-size: 12px; color: rgb(134, 134, 134); font-weight: 100; padding: 5px'>LEGALES</h6>
                        <h6 style='font-family:sans-serif !important; font-size: 12px; color: rgb(134, 134, 134); font-weight: 100; padding: 5px'>La valuación online no reviste el carácter de tasación inmobiliaria. La información y los datos personales brindados por Ud., en forma voluntaria, serán almacenados por EXCHANGE SERVICES S. A. (en adelante “NARVAEZ”), con el único fin de mantenerse en contacto con Ud. y remitirle la información relacionada al servicio de valuación online.  NARVAEZ no utilizará esta información para finalidades distintas o incompatibles con aquellas que motivaron su obtención.</h6>
                    </div>
                </div>
            </div>
		</div>
    </div>";

    $mailSender->sendEmail($to, $subject, $message);

