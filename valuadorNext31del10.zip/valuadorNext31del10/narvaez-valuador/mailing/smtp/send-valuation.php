<?php

	$domain = "http://".$_SERVER['HTTP_HOST'].substr($_SERVER['PHP_SELF'], 0, strrpos($_SERVER['PHP_SELF'], "/") + 1);
	
	$subject = "Valuación Online - Narvaez Inmobiliaria";
	$from = "info@holahellostudio.com";
	$to = $email;
	$bcc = 'tomas@holahellostudio.com';
	// $cco =

	$message ="
    <head>
        <meta charset='UTF-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>MailContent</title>
        <!-- <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet'
        integrity='sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC' crossorigin='anonymous'> -->
        <link href='https://fonts.cdnfonts.com/css/avenir' rel='stylesheet'>
    </head>
    
    <div style='background: rgb(207, 207, 207); padding-bottom: 6px; padding-top: 6px;'>
        
    <div  style='
            margin-right: auto; 
            margin-left: auto; 
            max-width: 575px;
            '>

            <div style='text-align: center; padding: 5px; background-color: #ffffff;'>
				<img src='https://www.narvaez.com.ar/valuador/assets/narvaez-border_02.png' alt='narvaez inmobiliaria logo'
                style='height: 48px;'>
			</div>
            <img src='https://www.narvaez.com.ar/valuador/assets/header_mail_2.png' alt='precio a tu propiedad'
            style='
                margin-right: auto; 
                margin-left: auto;
                width: 100%'>

			<div style='
                        background-color: #ffffff;  
                        padding-top: 15px; 
                        padding-bottom: 10px;
                        padding-right: 10px;
                        padding-left: 10px;
                        margin-bottom: 5px;


                        '>
					<h3 style='text-align: center; color: rgb(0, 0, 0);font-family:sans-serif !important;'>El valor estimado es:</h3>
					<h2 style='text-align: center; color: rgb(0, 0, 0); font-family:sans-serif !important;'>"; $message .= $value; $message .= "</h2>
					<p style='padding-left: 5px; padding-right: 5px; text-align: center; color:rgb(0, 0, 0);font-family:sans-serif !important;'>"; $message .= $txt; $message .= ", Argentina.</p>
			</div> 

			<div style='background-color: white; 
                        margin-right: auto; 
                        margin-left: auto;  
                        max-width: 575px; 
                        padding-bottom: 30px;
                        padding-left: 10px;
						padding-right: 10px;
                        '>

				
				<div style='padding-left: 5px; padding-right: 5px;'>

                    <div style='padding-top:10px; padding-left: 5px'>
                        <h3 style='font-family:sans-serif;'>¿Te gustaría mejorar el precio?</h3>
                    </div> 

                    <div style='
                                display: flex;
                                padding-top: 5px;
                                margin-bottom: 8px;
                            '   >
                        <img src='https://www.narvaez.com.ar/valuador/assets/icon2.PNG' alt='' style='height: 40px; margin-top: auto; margin-bottom: auto; margin-right: 8px;'>
                        <h5 style='font-family:sans-serif !important; font-size: 12px; font-weight: 100;'>Para obtener un precio adecuado, es indispensable realizar una Tasación presencial con un profesional matriculado.</h5>
                    </div>

                    <hr style='width: 100%; color: #e8e7e7; border: solid 1px;'>

                    <div style='
                                display: flex;
                                padding-top: 5px;
                                margin-bottom: 8px;
                            '   >
                        <img src='https://www.narvaez.com.ar/valuador/assets/icon4.PNG' alt='' style='height: 40px; margin-top: auto; margin-bottom: auto; margin-right: 8px;'>
                        <h5 style='font-family:sans-serif !important; font-size: 12px; font-weight: 100;'>El tasador asistirá a la propiedad y tomará en cuenta las características del inmueble: su estado general, dimensiones de los ambientes, disposición interna, ubicación en el barrio, entre otras variables relevantes.</h5>
                    </div>

                    <hr style='width: 100%; color: #e8e7e7; border: solid 1px;'>

                    <div style='
                                display: flex;
                                padding-top: 5px;
                                margin-bottom: 15px;
                            '   >
                        <img src='https://www.narvaez.com.ar/valuador/assets/icon3.PNG' alt='' style='height: 40px; margin-top: auto; margin-bottom: auto; margin-right: 8px;'>
                        <h5 style='font-family:sans-serif !important; font-size: 12px; font-weight: 100;'>En caso de solicitarlo, nuestro agente inmobiliario visitará la propiedad, y tomará en cuenta todas las características propias del inmueble, del barrio y del mercado, antes de presentarte el valor de tasación más acertado.</h5>
                    </div>

                    <div style='text-align: center;'>
                        <a type='button' style='
                                margin-top: 15px;
                                margin-bottom: 15px;
                                padding-top: 14px;
                                padding-bottom: 14px;
                                padding-left: 40px;
                                padding-right: 40px;
                                background-color: #C62C2C;
                                appearance: button;
                                color: white;
                                text-decoration: none;
                                font-family:sans-serif;
                                text-align: center;
                                font-size: 14px;
                                font-weight: 800;
                                letter-spacing: 3px;
            
                                '
                        href='https://www.narvaez.com.ar/valuador/thanks-contact.php?email="; $message .= $email; $message .="&tel=".$tel; $message .="'>SOLICITAR TASACIÓN</a>
                    </div>

                </div>
            
            </div>

			<div style='background-color: white; 
						margin-right: auto; 
						margin-left: auto; 
						margin-top: 5px; 
						max-width: 575px;
						padding-bottom:20px'>
				<div style='padding-left: 10px; padding-right: 10px;'>
					<div style='
								padding-top: 5px;
								margin-bottom: 8px;
							'   >
                        <h6 style='font-family:sans-serif !important; font-size: 12px; color: rgb(134, 134, 134); font-weight: 100; padding: 5px'>LEGALES</h6>
                        <h6 style='font-family:sans-serif !important; font-size: 12px; color: rgb(134, 134, 134); font-weight: 100; padding: 5px'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit.</h6>
                    </div>
                </div>
            </div>
		</div>
    </div>";

	$headers =  "From: Narvaez Inmobiliaria <".$from.">\r\n";
	$headers .= "Reply-To: ". $from . "\r\n";
	$headers .= "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	//$headers .= "Cc: ".$cc . "\r\n";
	$headers .= "Bcc: ".$bcc;

		if(mail($to,$subject,$message,$headers) == false)
			$error = 'Error while sending your inquire. Mail not sent.';

if($error === false)
	echo('OK');
else
	echo($error);


?>
