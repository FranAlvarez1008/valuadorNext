<?php

	$domain = "http://".$_SERVER['HTTP_HOST'].substr($_SERVER['PHP_SELF'], 0, strrpos($_SERVER['PHP_SELF'], "/") + 1);
	
	$subject = "Solicitud de Tasación - Narvaez Inmobiliaria";
	$from = "info@holahellostudio.com";
	$to = $email;
	$bcc = 'tomas@holahellostudio.com';
	// $cco =

	$message ="
    <head>
        <meta charset='UTF-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>MailContent</title>
    </head>

    <div style='background: rgb(207, 207, 207); padding-bottom: 6px; padding-top: 6px;'>

        <div  style='

            margin-right: auto; 
            margin-left: auto; 
            max-width: 575px;'>

            <div style='text-align: center; padding: 5px; background-color: #ffffff;'>
				<img src='https://www.narvaez.com.ar/valuador/assets/narvaez-border_02.png' alt='narvaez inmobiliaria logo'
                style='height: 49px;'>
			</div>
            <img src='https://www.narvaez.com.ar/valuador/assets/header_mail_2.png' alt='precio a tu propiedad'
            style='
                margin-right: auto; 
                margin-left: auto;
                width: 100%'>

			<div style='background-color: white; margin-right: auto; margin-left: auto; max-width: 575px; padding-bottom: 25px;'>

				
				<div style='
                            padding-left: 20px; 
                            padding-right: 20px;'>

                    <div style='padding-top: 40px; padding-left: 5px; text-align: center; margin-bottom: 25px;'>
                        <img src='https://www.narvaez.com.ar/valuador/assets/icon5.PNG' alt='' style='height: 40px;'>

                        <h3 style='font-family: sans-serif; text-align: center;'>¡Recibimos tu solicitud de tasación!</h3>
                    </div> 

                    <hr style='width: 100%; color: #e8e7e7; border: solid 1px;'>
                
                    <div style='
                                padding-top: 5px;
                                margin-bottom: 8px;
                                padding-left: 10px;
                                padding-right: 10px;
                            '   >
                        <h5 style='font-family: sans-serif !important; font-size: 12px; font-weight: 100;'>
                            Un agente se pondrá en contacto para coordinar una visita y tasar la propiedad.</h5>
                        <h5 style='font-family: sans-serif !important; font-size: 12px; font-weight: 100;'>
                            Por cualquier consulta adicional no dudes en contactarnos:
                        <br> Telefono:+54 11-4743-2090
                        <br> Whatsapp:+54 9 11 2829-9141
                        <br> mail: recepcion@narvaez.com.ar</h5>
                        <h5 style='font-family: sans-serif !important; font-size: 12px; font-weight: 100;'>
                            Muchas gracias. 
                        <br><span style='font-weight: 600;'>Narvaez Negocios Inmobiliarios.</span></h5>
                        
                    </div>

                </div>
            
            </div>
            <div style='
                        background-color: white; 
                        margin-right: auto; 
                        margin-left: auto; 
                        margin-top: 5px; 
                        max-width: 575px;'>
                <div style='
                            padding-left: 20px; 
                            padding-right: 20px; 
                            padding-bottom: 25px;'>
                    <div style='
                                padding-top: 5px;
                                margin-bottom: 25px;
                                padding-left: 10px;
                                padding-right: 10px;
                            '   >
                        <h6 style='
                                    font-family: sans-serif !important; 
                                    font-size: 12px; 
                                    color: rgb(134, 134, 134); 
                                    font-weight: 100; 
                                    padding-bottom: 5px; 
                                    margin-bottom: 4px;
                                    '>LEGALES</h6>
                        <h6 style='
                                    font-family: sans-serif !important; 
                                    font-size: 12px; 
                                    color: rgb(134, 134, 134); 
                                    font-weight: 100; 
                                    padding-top: 5px; 
                                    margin-top: 4px; 
                                    margin-bottom: 0px;
                                    '>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit.</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>";

	$headers =  "From: Narvaez Inmobiliaria <".$from.">\r\n";
	$headers .= "Reply-To: ". $form . "\r\n";
	$headers .= "MIME-Version: 1.0" . "\r\n";
	// $headers .= "Content-type:message/html;charset=UTF-8" . "\r\n";
    // $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
	//$headers .= "Cc: ".$cc . "\r\n";
	$headers .= "Bcc: ".$bcc;

		if(mail($to,$subject,$message,$headers) == false)
			$error = 'Error while sending your inquire. Mail not sent.';

if($error === false)
	echo('OK');
else
	echo($error);


?>
