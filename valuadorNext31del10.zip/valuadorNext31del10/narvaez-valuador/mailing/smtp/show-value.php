<?php

    require_once('./obtain-query-string.php');
 
    // generating text response   
    if( $tipo == 'casa')
        $txt = 'Casa con ';
    elseif($tipo=='dpto')
        $txt = 'Departamento con ';
    elseif($tipo=='ph')
        $txt = 'PH con ';
    elseif($tipo=='lote')
        $txt = 'Lote con ';
    
    if($tipo == 'lote'){
        $txt .= $m2tot.' m2 totales, ';
    }else{
        $txt .= $cant.' ';
        if($rooms == 'true')
            $txt .= 'ambientes, ';
        else
            $txt .= 'dormitorios, ';
        $txt .= $m2cub.' m2 cubiertos y '.$m2tot.' m2 totales, ';
        if($parking == 'on' && $parrilla == 'on' && $pool == 'on')
            $txt .= 'con parrilla, pileta y estacionamiento, ';
        elseif($parking == 'on' && $parrilla == 'on')
            $txt .= 'con parrilla y estacionamiento, ';
        elseif($parrilla == 'on' && $pool == 'on')
            $txt .= 'con parrilla y pileta, ';
        elseif($parking == 'on' && $pool == 'on')
            $txt .= 'con pileta y estacionamiento, ';
    }   

    if( $tipo == 'casa')
        $txt .= 'ubicada en '.$address.', ';
    else    
        $txt .= 'ubicado en '.$address.', ';

    if ($is_country == 1){
        $txt .= 'en el barrio privado de ';
        if ($country == 'Otro')
            $txt .= $otroCountry.', '.$partido.'.';
        else{
            $txt .= $country.', '.$partido.'.';
        }

    }else{
        $txt .= 'en ';
        $txt .= $localidad.', '.$partido.'.';
    }

    // DEBUG
    // echo($txt);

    

?>

    <!-- 
        Header
    -->

    <?php require_once './header.php'; ?>
    
    <img src="./assets/header_small_alta_2.jpg" class="img-header d-sm-none d-block" alt="precio a tu propiedad">
    <img src="./assets/header_desktop_2.jpg" class="d-sm-block d-none w-100" style="margin-top: 60px;"alt="precio a tu propiedad">

    <!-- 
        Form 
    -->

    <div class="container-back-no-index">

        <div class="mx-auto container-white ps-1 pe-1">
            
            <div class="col-sm-12 pt-sm-4 pb-sm-4 pt-4 pb-5 mb-5" style="background-color: #777777;">
                <div class="mx-auto col-sm-6 col-12">
                    <h3 class="text-center" style="color: white;">El precio estimado es:</h3>
                    <h2 class="text-center"style="color: white;"><?php echo($value) ?></h2>
                    <p class="small-txt text-center mx-auto p-3 mb-0 pb-sm-0" style="color: white;"><?php echo($txt) ?> - Argentina.</p>
                </div>
            </div> 
            
            <div class="mx-auto body-width mb-5 mb-sm-5 ps-3 pe-3 ps-sm-0 pe-sm-0">

                <div class="me-4 col-sm-12">
                    <h4 >¿Te gustaría mejorar el precio?</h4>
                </div> 

                <div class="d-flex pt-3 mt-4 mb-4">
                    <div class="d-flex flex-direction-column justify-content-center">
                        <img src="./assets/icon2.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <h6 class="sm-col-9 small-txt ps-2 ps-md-4 pt-3">El rango de precio informado se obtiene comparando los parámetros de tu propiedad con nuestra base de datos.</h6>
                </div>

                <hr style="width: 100%;">

                <div class="d-flex mt-3 mb-3 ">
                    <div class="d-flex flex-direction-column justify-content-center">
                        <img src="./assets/icon4.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <h6 class="sm-col-9 small-txt ps-2 ps-md-4 mt-3 mb-3 mb-0">Para obtener un precio adecuado, es indispensable realizar una Tasación presencial con un profesional matriculado.</h6>
                </div>

                <hr style="width: 100%;">

                <div class="d-flex mt-3 mb-4">
                    <div class="d-flex flex-direction-column justify-content-center">
                        <img src="./assets/icon3.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <h6 class="sm-col-9 small-txt ps-2 ps-md-4 mt-3 mb-4" >El tasador asistirá a la propiedad y tomará en cuenta las características del inmueble: su estado general, dimensiones de los ambientes, disposición interna, ubicación en el barrio, entre otras variables relevantes.</h6>
                </div>

                <div class="d-sm-flex justify-content-between align-center mt-5 mb-5 mb-sm-4 col-sm-12 col-12" style="margin-bottom: 30px !important;">
                    <a type="button" class="btn button-primary   col-12 col-sm-6 small-txt font-weight-bolder btn-heigth" href="/valuador/thanks-contact.php?email=<?php echo($email)?>&tel=<?php echo($tel) ?>">SOLICITAR TASACIÓN</a>
                    <a type="button" class="btn btn-volver col-12 col-sm-6 small-txt ms-sm-1 mt-3 mt-sm-0 btn-heigth" href="/valuador/index.php?<?php echo('email='.$email.'&tel='.$tel)?>"><spam><img src="./assets/arrow.png" alt="" class="me-2" style="margin-bottom: 2px;"></spam>VOLVER A VALUAR</a>
                </div>
            
                <div class="mt-5 mb-5" style="height: 5px;"></div>
            </div>

        </div>

    </div>


<!-- 
    Footer 
-->

    <?php 
    
        require_once('./footer.php'); 
    
        require_once ('./mailing/send-valuation.php');

    ?>