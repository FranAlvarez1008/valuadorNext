<?php
 
/**
 * PHPMailer - PHP email creation and transport class.
 * PHP Version 5.5
 * @package PHPMailer
 * @see https://github.com/PHPMailer/PHPMailer/ The PHPMailer GitHub project
 * @author Marcus Bointon (Synchro/coolbru) <phpmailer@synchromedia.co.uk>
 * @author Jim Jagielski (jimjag) <jimjag@gmail.com>
 * @author Andy Prevost (codeworxtech) <codeworxtech@users.sourceforge.net>
 * @author Brent R. Matzelle (original founder)
 * @copyright 2012 - 2020 Marcus Bointon
 * @copyright 2010 - 2012 Jim Jagielski
 * @copyright 2004 - 2009 Andy Prevost
 * @license http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License
 * @note This program is distributed in the hope that it will be useful - WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 */
 
namespace PHPMailer\PHPMailer;
 
use League\OAuth2\Client\Provider\Google;
 
require '../vendor/autoload.php';
require_once './class-db.php';
 
session_start();
 
// Read the JSON file 
$json = file_get_contents('./credentials.json');
  
// Decode the JSON file
$json_data = json_decode($json,true);

$clientId = $json_data['web']['client_id'];
$clientSecret =  $json_data['web']['client_secret'];
// $clientId = 'GOOGLE_CLIENT_ID';
// $clientSecret = 'GOOGLE_CLIENT_SECRET';
 
//If this automatic URL doesn't work, set it yourself manually to the URL of this script
$redirectUri = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
//$redirectUri = 'http://localhost/PHPMailer/redirect';
 
$params = [
    'clientId' => $clientId,
    'clientSecret' => $clientSecret,
    'redirectUri' => $redirectUri,
    'accessType' => 'offline'
];
$options = [
    'scope' => [
        'https://mail.google.com/'
        ]
    ,
    'prompt' => 'consent',       // Descomentar para obtener nuevo refresh token
    'access_type' => 'offline'   // Ambas lineas
];
$provider = new Google($params);
  
if (!isset($_GET['code'])) {
    //If we don't have an authorization code then get one
    $authUrl = $provider->getAuthorizationUrl($options);
    $_SESSION['oauth2state'] = $provider->getState();
    header('Location: ' . $authUrl);
    exit;
    //Check given state against previously stored one to mitigate CSRF attack
} elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {
    unset($_SESSION['oauth2state']);
    unset($_SESSION['provider']);
    exit('Invalid state');
} else {
    unset($_SESSION['provider']);
    //Try to get an access token (using the authorization code grant)
    $token = $provider->getAccessToken(
        'authorization_code',
        [
            'code' => $_GET['code']
        ]
    );
    //Use this to interact with an API on the users behalf
    //Use this to get a new access token if the old one expires
    // echo 'Refresh Token: ', $token->getRefreshToken();
 
    $db = new \DB();
    // if($db->is_token_empty()) {
        // $db->update_refresh_token($token);
        $token_decode = json_encode ( $token );
        $db->update_refresh_token($token_decode);
        echo "Token inserted successfully.";
    // }else{
        // $token_db = $db->update_refresh_token($token->getRefreshToken());

        // $token_decode = json_encode ( $token );
        // $db->update_refresh_token($token_decode);
    
        // $db->update_refresh_token($token);
        // $token_db = json_decode($db->get_access_token());
        // var_dump($token_db->getRefreshToken());
    // }
}