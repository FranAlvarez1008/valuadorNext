<?php

    require './mailing/send_mail.php';
    // $from = 'tomas@holahellostudio.com';
    $from ='recepcion@narvaez.com.ar';
    $mailSender = new SendEmail($from);

	$subject = "Solicitud de Tasación - Narvaez Inmobiliaria";
    $to = $email;	

	$message ="
    <head>
        <meta charset='UTF-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>MailContent</title>
    </head>

    <div style='background: rgb(207, 207, 207); padding-bottom: 6px; padding-top: 6px;'>

        <div  style='

            margin-right: auto; 
            margin-left: auto; 
            max-width: 575px;'>

            <div style='text-align: center; padding: 5px; background-color: #ffffff;'>
				<img src='https://www.narvaez.com.ar/valuador/assets/narvaez-border_02.png' alt='narvaez inmobiliaria logo'
                style='height: 49px;'>
			</div>
            <img src='https://www.narvaez.com.ar/valuador/assets/header_mail_2.png' alt='precio a tu propiedad'
            style='
                margin-right: auto; 
                margin-left: auto;
                width: 100%'>

			<div style='background-color: white; margin-right: auto; margin-left: auto; max-width: 575px; padding-bottom: 25px;'>

				
				<div style='
                            padding-left: 20px; 
                            padding-right: 20px;'>

                    <div style='padding-top: 40px; padding-left: 5px; text-align: center; margin-bottom: 25px;'>
                        <img src='https://www.narvaez.com.ar/valuador/assets/icon5.PNG' alt='' style='height: 40px;'>

                        <h3 style='font-family: sans-serif; text-align: center;'>¡Recibimos tu solicitud de tasación!</h3>
                    </div> 

                    <hr style='width: 100%; color: #e8e7e7; border: solid 1px;'>
                
                    <div style='
                                padding-top: 5px;
                                margin-bottom: 8px;
                                padding-left: 10px;
                                padding-right: 10px;
                            '   >
                        <h5 style='font-family: sans-serif !important; font-size: 12px; font-weight: 100;'>
                            Un agente se pondrá en contacto para coordinar una visita y tasar la propiedad.</h5>
                        <h5 style='font-family: sans-serif !important; font-size: 12px; font-weight: 100;'>
                            Por cualquier consulta adicional no dudes en contactarnos:
                        <br>- Telefono:+54 11-4743-2090
                        <br>- Whatsapp:+54 9 11 2829-9141
                        <br>- mail: recepcion@narvaez.com.ar</h5>
                        <h5 style='font-family: sans-serif !important; font-size: 12px; font-weight: 100;'>
                            Muchas gracias. 
                        <br><span style='font-weight: 600;'>Narvaez Negocios Inmobiliarios.</span></h5>
                        
                    </div>

                </div>
            
            </div>
            <div style='
                        background-color: white; 
                        margin-right: auto; 
                        margin-left: auto; 
                        margin-top: 5px; 
                        max-width: 575px;'>
                <div style='
                            padding-left: 20px; 
                            padding-right: 20px; 
                            padding-bottom: 25px;'>
                    <div style='
                                padding-top: 5px;
                                margin-bottom: 25px;
                                padding-left: 10px;
                                padding-right: 10px;
                            '   >
                        <h6 style='
                                    font-family: sans-serif !important; 
                                    font-size: 12px; 
                                    color: rgb(134, 134, 134); 
                                    font-weight: 100; 
                                    padding-bottom: 5px; 
                                    margin-bottom: 4px;
                                    '>LEGALES</h6>
                        <h6 style='
                                    font-family: sans-serif !important; 
                                    font-size: 12px; 
                                    color: rgb(134, 134, 134); 
                                    font-weight: 100; 
                                    padding-top: 5px; 
                                    margin-top: 4px; 
                                    margin-bottom: 0px;
                                    '>La valuación online no reviste el carácter de tasación inmobiliaria. La información y los datos personales brindados por Ud., en forma voluntaria, serán almacenados por EXCHANGE SERVICES S. A. (en adelante “NARVAEZ”), con el único fin de mantenerse en contacto con Ud. y remitirle la información relacionada al servicio de valuación online.  NARVAEZ no utilizará esta información para finalidades distintas o incompatibles con aquellas que motivaron su obtención.</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>";

    $mailSender->sendEmail($to, $subject, $message);


    ?>