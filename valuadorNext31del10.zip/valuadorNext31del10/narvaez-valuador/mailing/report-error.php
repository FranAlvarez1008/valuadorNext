<?php
    class ReportError {
        private $domain;
        private $subject;
        private $from = "info@holahellostudio.com";
        private $to;
        private $bcc = 'tomas@holahellostudio.com';
        private $message;

        public function __construct() {
            $this->domain = "http://".$_SERVER['HTTP_HOST'].substr($_SERVER['PHP_SELF'], 0, strrpos($_SERVER['PHP_SELF'], "/") + 1);
            $this->subject = "Error en envio de mail - Valuador";
        }

        public function reportErrorEmail($mail_to, $message_error){
            $this->to = $mail_to;
            $this->message = $message_error;
            $headers =  "From: Narvaez Inmobiliaria <".$this->from.">\r\n";
            $headers .= "Reply-To: ". $this->from . "\r\n";
            $headers .= "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "Bcc: ".$this->bcc;
            mail($this->to,$this->subject,$this->message,$headers);
        }
    }
?>
