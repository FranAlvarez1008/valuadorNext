<?php
    require_once '../valuador/vendor/autoload.php';
    require_once './mailing/class-db.php';
    require_once './mailing/report-error.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\OAuth;
    use League\OAuth2\Client\Provider\Google;

    class SendEmail {

        private $email;
        private $mail;
        private $json_data;
        private $clientId;
        private $clientSecret;
        private $db;
        private $refreshToken;
        private $provider;
        private $from;
        private $sender_name;

        public function __construct($from){
            $this->sender_name = 'Narvaez Inmobiliaria';
            $this->db = new \DB();
            $this->from = $from;
            $this->mail = new PHPMailer();
            $this->mail->isSMTP();
            $this->mail->Host = 'smtp.gmail.com';
            $this->mail->Port = 465;
            $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $this->mail->SMTPAuth = true;
            $this->mail->AuthType = 'XOAUTH2';
            $this->email = $this->from; // the email used to register google app
            $this->mail->addBCC($this->from);
            $this->refreshToken = $this->db->get_refersh_token();
            // Decode the JSON credentials file
            $json = file_get_contents('./mailing/credentials.json');
            $this->json_data = json_decode($json,true);
            $this->clientId = $this->json_data['web']['client_id'];
            $this->clientSecret =  $this->json_data['web']['client_secret'];
            //Create a new OAuth2 provider instance
            $this->provider = new Google(
                [
                    'clientId' => $this->clientId,
                    'clientSecret' => $this->clientSecret,
                ]
            );
            //Pass the OAuth provider instance to PHPMailer
            $this->mail->setOAuth(
                new OAuth(
                    [
                        'provider' => $this->provider,
                        'clientId' => $this->clientId,
                        'clientSecret' => $this->clientSecret,
                        'refreshToken' => $this->refreshToken,
                        'userName' => $this->email,
                    ]
                )
            );
            $this->mail->setFrom($this->email, $this->sender_name);
            $this->mail->isHTML(true);

        }
    
        public function sendEmail($to, $subject, $message){
            $this->mail->addAddress($to);
            $this->mail->Subject = $subject;
            $this->mail->Body = $message;
            $this->mail->CharSet = 'UTF-8';
            // send the message, check for errors
            if (!$this->mail->send()){
                $reportErrorMail = new ReportError();
                $reportErrorMail->reportErrorEmail($this->from, $this->mail->ErrorInfo);
            }
        }

    }
    
?>