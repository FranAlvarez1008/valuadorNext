<?php
    $ip = $_SERVER['REMOTE_ADDR'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valuador Online</title>
    <link rel="icon" type="image/x-icon" href="./assets/favicon.png">
    <!-- CSS only -->
    <link rel="stylesheet" href="./css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.cdnfonts.com/css/avenir" rel="stylesheet">

    <style>
        @import url('https://fonts.cdnfonts.com/css/avenir');
    </style>

    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KGMLFKV');</script>
<!-- End Google Tag Manager -->

</head>

<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KGMLFKV"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid px-sm-5">
          <a class="navbar-brand" href="https://www.narvaez.com.ar/">
            <img class="logo" src="./assets/narvaez-border_02.svg" alt="Narvaez logo">
          </a>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href='https://www.narvaez.com.ar/propiedades/?order_by=id&order=DESC&limit=15&offset=15&data=%7B"current_localization_id"%3A0%2C"current_localization_type"%3A"division"%2C"price_from"%3A0%2C"price_to"%3A999999999%2C"operation_types"%3A%5B1%2C2%2C3%5D%2C"property_types"%3A%5B1%2C2%2C3%2C4%2C5%2C6%2C7%2C8%2C9%2C10%2C11%2C12%2C13%2C14%2C15%2C16%2C17%2C18%2C19%2C20%2C21%2C22%2C23%2C24%2C25%5D%2C"currency"%3A"ANY"%2C"filters"%3A%5B%5D%7D'>Propiedades</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://www.narvaez.com.ar/emprendimientos/">Emprendimientos</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://www.narvaez.com.ar/inmuebles-industriales/">Industriales</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://www.narvaez.com.ar/tasaciones/">Tasaciones</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://www.narvaez.com.ar/nosotros/">Nosotros</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://www.narvaez.com.ar/contacto/">Contacto</a>
              </li>
            </ul>
          </div>
          <div id="menuArea">
            <input type="checkbox" id="menuToggle"></input>
            <label for="menuToggle" class="menuOpen d-sm-block d-md-block d-lg-none mb-0">
              <div class="open"></div>
            </label>
            <div class="menu menuEffects">
              <label for="menuToggle"></label>
              <div class="menuContent">
                <ul>
                  <li><a href='https://www.narvaez.com.ar/propiedades/?order_by=id&order=DESC&limit=15&offset=15&data=%7B"current_localization_id"%3A0%2C"current_localization_type"%3A"division"%2C"price_from"%3A0%2C"price_to"%3A999999999%2C"operation_types"%3A%5B1%2C2%2C3%5D%2C"property_types"%3A%5B1%2C2%2C3%2C4%2C5%2C6%2C7%2C8%2C9%2C10%2C11%2C12%2C13%2C14%2C15%2C16%2C17%2C18%2C19%2C20%2C21%2C22%2C23%2C24%2C25%5D%2C"currency"%3A"ANY"%2C"filters"%3A%5B%5D%7D'>Propiedades</a></li>
                  <li><a href="https://www.narvaez.com.ar/emprendimientos/">Emprendimientos</a></li>
                  <li><a href="https://www.narvaez.com.ar/inmuebles-industriales/">Industriales</a></li>
                  <li><a href="https://www.narvaez.com.ar/tasaciones/">Tasaciones</a></li>
                  <li><a href="https://www.narvaez.com.ar/nosotros/">Nosotros</a></li>
                  <li><a href="https://www.narvaez.com.ar/contacto/">Contacto</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </nav>



