    <!-- 
        Header
    -->

    <?php require_once('./header.php'); ?>

p
    <!-- desktop -->
    <div class="d-none d-md-flex header-img-desk w-100 h-3">
        <!-- big clean -->
        <div class="d-flex justify-center col-6 ms-auto me-0 ps-xl-5">
            <img class="w-75 mx-auto my-auto" src="./assets/txt.png" alt="precio a tu propiedad texto">
        </div>
        <!-- text clenan -->
        <!-- <img class="" src="./assets/bg_header-desktop-clean.jpg" alt="precio a tu propiedad imagen"> -->
    </div>
    <!-- desk mediun size -->
    <img class="d-none  d-sm-block d-md-none w-100" style="margin-top: 60px;" src="./assets/header_desktop_2.jpg" alt="precio a tu propiedad">

    <!-- movile -->
    <img class="d-block d-sm-none d-md-none img-header" src="./assets/header_small_alta_2.jpg" alt="precio a tu propiedad">

    <!-- 
        Form 
    -->

    <div class="d-block d-md-flex">
        <div class="container-back pt-1 pb-1 col-md-6 px-lg-5 col-xl-7">

            <div class="valuador-container  
                    mx-auto mt-0 mb-0 p-4
                    my-sm-5 mx-sm-2
                    ">

                <div class="col-sm-12">
                    <h4 class="text-center mt-3">VALUACIÓN ONLINE</h4>
                    <p class="small-txt text-center">Completá los siguientes datos y conocé el valor estimado de tu propiedad:
                    </p>
                </div>

                <form name="form" method="post" action="./results.php" id="form" class="d-sm-flex flex-wrap" method="POST">

                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 pe-sm-1 pe-md-0 pe-xl-1 mt-3 mt-sm-4 ">
                        <label for="name" class="form-label small-txt">Nombre</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Ingresá tu Nombre" required>
                    </div>
                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 ps-sm-1 ps-md-0 ps-xl-1 mt-3 mt-sm-4">
                        <label for="apellido" class="form-label small-txt">Apellido</label>
                        <input type="text" class="form-control" name="apellido" id="apellido" placeholder="Ingresá tu Apellido" required>
                    </div>
                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 pe-sm-1 pe-md-0 pe-xl-1 mt-3 mt-sm-4 ">
                        <label for="email" class="form-label small-txt">E-mail *</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="Ingresá tu e-mail" required>
                    </div>
                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 ps-sm-1 ps-md-0 ps-xl-1 mt-3 mt-sm-4">
                        <label for="tel" class="form-label small-txt">Teléfono *</label>
                        <input type="tel" class="form-control" name="tel" id="tel" placeholder="Código de area + Nro. de teléfono" required>
                    </div>
                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 pe-sm-1 pe-md-0 pe-xl-1 mt-3 mt-sm-4">
                        <label for="partido" class="form-label small-txt">Partido *</label>
                        <select id="partido" name="partido" class="form-select" required>
                            <option value="" disabled selected>Seleccione Partido</option>
                        </select>
                    </div>
                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 ps-sm-1 ps-md-0 ps-xl-1 mt-3 mt-sm-4">
                        <label for="localidad" class="form-label small-txt">Localidad *</label>
                        <select id="localidadId" name="localidadId" class="form-select" required>
                            <option value="" disabled selected>Seleccione Localidad</option>>
                        </select>
                    </div>

                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 pe-sm-1 pe-md-0 pe-xl-1 mt-3 mt-sm-4" id="boxLocalidad">
                        <label for="address" class="form-label small-txt">Dirección de la propiedad a valuar*</label>
                        <input type="text" id="address" name="address" class="form-control" placeholder="Dirección" required>
                    </div>

                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 ps-sm-1 ps-md-0 ps-xl-1 mt-3 mt-sm-4">
                        <label for="tipo" class="form-label small-txt">Tipo de Propiedad *</label>
                        <select id="tipo" name="tipo" class="form-select" required>
                            <option value="" disabled selected>Tipo de Propiedad</option>
                            <option value="casa">Casa</option>
                            <option value="dpto">Departamento</option>
                            <option value="ph">PH (Propiedad Horizontal)</option>
                            <option value="lote">Lote</option>
                        </select>
                    </div>

                    <div id="countryBox" class="d-sm-flex col-12 flex-wrap">

                        <div class="col-12 col-sm-6 col-md-12 col-xl-6 ps-sm-1 mt-3 mt-sm-4">
                        </div>

                        <div class="col-12 col-sm-6 col-md-12 col-xl-6 ps-0 ps-sm-1 mt-3 mt-sm-4 form-check form-switch">
                            <input class="form-check-input ms-0 me-2" type="checkbox" id="isCountry" name="isCountry">
                            <label class="form-check-label small-txt" for="barrioCerrado" disabled>Se encuentra en un barrio cerrado</label>
                        </div>
                        <div id="barrio" class="d-none col-sm-12 col-md-12 col-12 mt-3 mt-sm-4 pe-sm-1">
                            <label for="barrio" class="form-label small-txt">Barrio privado</label>
                            <select name="nombreBarrio" id="nombreBarrio" class="form-select" >
                                <option value="none" disabled selected>Seleccione Barrio</option>
                            </select>
                        </div>

                        <div class="d-none col-12 col-sm-6 col-md-12 col-xl-6 mt-3 mt-sm-4 ps-sm-1" id="otroCountry">
                            <label class="form-label small-txt" for="otroCountry">Ingrese el nombre del barrio privado</label>
                            <input type="text" name="otroCountry" class="form-control" placeholder="Nombre de barrio privado">
                        </div>
                    </div>


                    <div id="plusHomePH" class="d-blok  col-12 col-sm-6 col-md-12 col-xl-6 mt-4">
                        <label for="" class="form-label mb-1 small-txt">Comodidades</label>
                        <div class="d-flex justify-content-between">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="cochera" name="cochera">
                                <label class="form-check-label small-txt" for="cochera" id="cochera">
                                    Cochera
                                </label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="pileta" name="piletaHome">
                                <label class="form-check-label small-txt" for="pileta" id="pileta">
                                    Pileta
                                </label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="parrilla" name="parrilla">
                                <label class="form-check-label small-txt" for="parrilla" id="parrilla">
                                    Parrilla
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="d-sm-block d-none col-sm-6 d-md-none d-xl-block"></div>

                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 pe-sm-1 mt-4">
                        <label for="" class="form-label small-txt">Ambientes / Dormitorios *</label>
                        <div class="d-flex ast-flex-direction-row ">
                            <div class="form-check" style="height: 32px !important;">
                                <input class="form-check-input round" type="radio" name="rooms" id="ambientes" value="rooms" checked>
                                <label class="form-check-label small-txt" for="ambientes">Ambientes</label>
                            </div>
                            <div class="form-check ms-3">
                                <input class="form-check-input round" type="radio" name="rooms" id="habitaciones" value="bedrooms">
                                <label class="form-check-label" for="habitaciones">
                                    Dormitorios
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-12 col-xl-6 mt-4">
                        <label for="cantidad" class="small-txt mb-2">Cantidad de Ambientes / Dormitorios*</label>
                        <div class="input-group mb-3 col-sm-6 col-9 boxCant">
                            <button id='res' type="button" class="input-group-text font-weight-bold btn-secondary" style="width: 33% !important; justify-content: center;" onclick="resBedRoom()">-</button>
                            <input type="number" min="1" value=1 id="cantidad" style="text-align: center;" name="cantidad" class="form-control" required>
                            <button id='sum' type="button" class="input-group-text font-weight-bold btn-dark" style="width: 33% !important; border-radius: 0px 4px 4px 0px !important; justify-content: center;" onclick="sumBedRoom()">+</button>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-4 col-12 col-sm-12">
                        <div class="col-6 pe-1">
                            <label for="m2cub" class="form-label small-txt">Superficie cubierta *</label>
                            <div class="input-group mb-3 col-5">
                                <span class="input-group-text small-txt">M2</span>
                                <input class="form-control" name="m2cub" id="m2cub" type="number" placeholder="0" min="0" required>
                                <span class="input-group-text tootlip-box">
                                    <img src="./assets/tooltip.png" alt="" style="height: 20px;" class="mt-auto mb-auto tt-icon" data-bs-toggle="tooltip" title="Cantidad de metros construidos. Si la propiedad tiene más de una planta, se deben considerar ambas superficies.. Ejemplo: Planta Baja 100 metros, 1er Piso, 80 metros = 180 Metros cubiertos.">
                                </span>
                            </div>
                        </div>


                        <div class="col-6 ps-1">
                            <label for="m2tot" class="form-label small-txt">Superficie total *
                            </label>
                            <div class="input-group mb-3 col-5 ">
                                <span class="input-group-text small-txt">M2</span>
                                <input class="form-control " name="m2tot" id="m2tot" type="number" placeholder="0" min="0" required>
                                <span class="input-group-text tootlip-box">
                                    <img src="./assets/tooltip.png" alt="" style="height: 20px;" class="mt-auto mb-auto tt-icon" data-bs-toggle="tooltip" title="Metros totales del terreno donde está implantada la propiedad.">
                                </span>
                            </div>
                        </div>

						<input type="hidden" id="ipInput" name="ipInput" value="<?=$ip;?>" required>

                    </div>

                    <button type="submit" class="btn button-primary col-12 my-4 my-xl-5 small-txt btn-heigth" id="btnSubmit">VALUAR MI PROPIEDAD</button>
                    <!-- <button type="submit" class="btn button-primary col-12 my-4 my-xl-5 small-txt btn-heigth" id="btnSubmit" onclick="obtainFormData(event)">VALUAR MI PROPIEDAD</button> -->

                </form>

            </div>

        </div>

        <!-- 
            disclaimer
        -->

        <div class="px-4 ps-xl-0
                mx-auto mt-2
                col-md-6 
                col-xl-5
                mb-0
                mb-md-0">

            <div class="mx-auto mt-sm-3 mt-4 mt-md-3 mb-sm-2 pt-2 pb-1">
                <h5>¿Cómo hacemos el cálculo?</h5>
                <div class="d-flex pt-3">
                    <div class="">
                        <img src="./assets/icon1.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <div class="d-flex flex-column justify-content-center">
                        <h6 class="sm-col-9 small-txt ps-2 m-0">Nuestro algoritmo busca y compara precios de propiedades con las mismas características y ubicación geográfica qué las ingresadas.</h6>
                    </div>
                </div>
                <div class="border-top d-flex pt-3 mt-2">
                    <div class="">
                        <img src="./assets/icon3.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <div class="d-flex flex-column justify-content-center">
                        <h6 class="sm-col-9 small-txt ps-2 m-0">Selecciona las propiedades más relevantes analizando nuestra base de datos.</h6>
                    </div>
                </div>
                <div class="border-top d-flex pt-3 mt-2">
                    <div class="">
                        <img src="./assets/icon5.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <div class="d-flex flex-column justify-content-center">
                        <h6 class="sm-col-9 small-txt ps-2 m-0">Por último, aplica un rango de variación de precio posible de venta y entrega el resultado.</h6>
                    </div>
                </div>
            </div>

            <div class="mx-auto mt-sm-3 mb-sm-2 mt-4 mt-md-3 pb-4">
                <h5>¿La valuación es un precio de venta final?</h5>
                <div class="d-flex pt-3">
                    <div class="">
                        <img src="./assets/icon6.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <div class="d-flex flex-column justify-content-center">
                        <h6 class="sm-col-9 small-txt ps-2">Nuestro precio surge de una valuación online por lo tanto debe ser tomado como una opinión de valor. La valuación online no reviste el carácter de tasación inmobiliaria.</h6>
                    </div>
                </div>
                <div class="border-top d-flex pt-3 mt-2">
                    <div class="">
                        <img src="./assets/icon4.PNG" alt="" style="height: 40px;" class="mt-auto mb-auto">
                    </div>
                    <div class="d-flex flex-column justify-content-center">
                        <h6 class="sm-col-9 small-txt ps-2">Para obtener un precio adecuado, es indispensable realizar una Tasación presencial con un profesional matriculado.</h6>
                    </div>
                </div>
                <div class="border-top d-flex pt-3 mt-2">
                    <div class="">
                        <img src="./assets/icon3.PNG" alt="" style="height: 40px;" class="my-auto">
                    </div>
                    <div class="d-flex flex-column justify-content-center">
                        <h6 class="sm-col-9 small-txt ps-2">El tasador asistirá a la propiedad y tomará en cuenta las características del inmueble: verificará los planos y titularidad del inmueble, su estado general, dimensiones de los ambientes, disposición interna, ubicación en el barrio, entre otras variables relevantes.</h6>
                    </div>
                </div>

            </div>

        </div>
    </div>

    <h6 class="legales p-4 pt-0 px-md-3 px-lg-5 mx-lg-2">LEGALES: La valuación online no reviste el carácter de tasación inmobiliaria. La información y los datos personales brindados por Ud., en forma voluntaria, serán almacenados por EXCHANGE SERVICES S. A. (en adelante “NARVAEZ”), con el único fin de mantenerse en contacto con Ud. y remitirle la información relacionada al servicio de valuación online. NARVAEZ no utilizará esta información para finalidades distintas o incompatibles con aquellas que motivaron su obtención.</h6>

    <div class="" style="height: 40px"></div>
    <!-- <div class="d-none d-xl-block" style="height: 20px"></div> -->


    <!-- 
        Footer 
    -->

    <?php 

        echo('<script type="text/javascript" src="https://api.clientify.net/web-marketing/webforms/external/script/136881.js"></script>');
        // echo('<script src="./js/main.js" type="text/javascript"></script>');
    
        require_once('./footer.php') 
    
    ?>

