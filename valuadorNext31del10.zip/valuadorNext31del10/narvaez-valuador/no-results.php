<?php 
    // ob_start();
    // // Iniciar la sesión
    // session_start();
    // // // Acceder a los datos almacenados en las variables de sesión
    // $txt   = $_SESSION['txt'];
    // $email = $_SESSION['email'];
    // $tel   = $_SESSION['tel'];
    // // // Limpiar las variables de sesión si ya no se necesitan
    // unset($_SESSION['txt']);
    // unset($_SESSION['email']);
    // unset($_SESSION['tel']);
    if (isset($_GET['txt']))
        $txt = $_GET['txt'];
    else
        $txt = "none";
    if (isset($_GET['email']))
        $email = $_GET['email'];
    else
        $email = "none";
    if (isset($_GET['tel']))
        $tel = $_GET['tel'];
    else
        $tel = "none";
    
    $msg = $txt."- Argentina. - Precio estimado: SIN RESULTADOS";

    // echo("mail: ".$email." - tel: ".$tel." - msg: ".$msg);
?>
    
    
    <!--
        header 
    -->

<?php 

    require_once './header.php'; 

?>
   
    <img src="./assets/header_small_alta_2.jpg" class="img-header d-sm-none d-block" alt="precio a tu propiedad">
    <img src="./assets/header_desktop_2.jpg" class="d-sm-block d-none w-100" style="margin-top: 60px;"alt="precio a tu propiedad">

    <!-- 
        Form 
    -->

    <div class="container-back-no-index pb-1">
        <div class="mx-auto container-white p-4" style="margin-top:0px;">
            <div class="d-sm-flex flex-wrap mx-auto body-width">
            
                <div class="pt-3 mt-0 mt-sm-4 mb-4">
                    <div class="d-flex justify-content-center mb-3">
                        <img src="./assets/icon6.PNG" alt="" style="height: 40px;" class="mx-auto">
                    </div>
                    <h5 class="sm-col-9 ps-2 text-center">Tu propiedad es única. Actualmente no contamos con publicaciones de propiedades similares a la tuya para poder realizar la valuación.</h5>
                    <!-- <h5 class="sm-col-9 ps-2 text-center">Lo sentimos, el sistema no cuenta con la suficiente información para valuar esta propiedad.</h5> -->
                </div>

                <hr style="width: 100%;">

                <div class="pt-3 mt-4 mt-sm-1">
                    <h4 class="sm-col-9 ps-2 text-center mx-auto">No te preocupes, podés solicitar una <span style="font-weight: bolder !important;">tasación presencial</span> para conocer el valor de tu propiedad</h4>
                </div>

                <div class="d-sm-flex justify-content-between align-center mt-5 mb-1 mb-sm-4 col-sm-12 col-12">
                    <form name="solicitar-tasacion" method="post" action="./thanks-contact.php?email=<?php echo($email)?>&tel=<?php echo($tel)?>&msg=<?php echo($msg)?>"  class="col-12 col-sm-6 small-txt ms-sm-1 mt-3 mt-sm-0">
                        <input type="hidden" id="email"   name="email"   value="<?php echo($email)?>">
                        <input type="hidden" id="tel"     name="tel"     value="<?php echo($tel)?>">
                        <input type="hidden" id="message" name="message" value="<?php echo($msg)?>">
                        <button type="submit" class="btn button-primary w-100 h-100 btn-heigth">SOLICITAR TASACIÓN</button>
                    </form>    
                    <a type="button" class="btn btn-volver col-12 col-sm-6 small-txt ms-sm-1 mt-3 mt-sm-0 btn-heigth" href="/valuador/index.php?<?php echo('email='.$email.'&tel='.$tel)?>"><spam><img src="./assets/arrow.png" alt="" class="me-2" style="margin-bottom: 2px;"></spam>VOLVER A VALUAR</a>
                </div>
                
                <div style="height: 20px;"></div>

            </div>
        </div>
    </div>

    <h6 class="legales p-4 pt-0 px-md-3 px-lg-5 mx-lg-2 mb-5" >LEGALES: La valuación online no reviste el carácter de tasación inmobiliaria. La información y los datos personales brindados por Ud., en forma voluntaria, serán almacenados por EXCHANGE SERVICES S. A. (en adelante “NARVAEZ”), con el único fin de mantenerse en contacto con Ud. y remitirle la información relacionada al servicio de valuación online.  NARVAEZ no utilizará esta información para finalidades distintas o incompatibles con aquellas que motivaron su obtención.</h6>


<?php 
    echo('<script type="text/javascript" src="https://api.clientify.net/web-marketing/webforms/external/script/138197.js"></script>');      

    require_once('./footer.php'); 

    // if($txt != ""){
    //     require_once('./to-clientify.php');
        
    //     // require_once('./mailing/send-valuation.php');
    // }
        
?>