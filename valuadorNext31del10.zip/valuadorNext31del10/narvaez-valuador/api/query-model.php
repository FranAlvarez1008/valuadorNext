<?php

class QueryModel
{
    private $db;

    public function __construct()
    {
        // $this->db = new PDO('mysql:host=localhost;' . 'dbname=valuador;charset=utf8', 'root', '');
        $this->db = new PDO('mysql:host=mysql.narvaez.com.ar;' . 'dbname=valuador;charset=utf8', 'valuador', 'DeFrGt&22');

    }

    // ---------- GET ONE

    function getOne($id)
    {
        $query = $this->db->prepare(
            'SELECT * 
            FROM query_prop 
            WHERE id_query = ?'
        );
        $query->execute([$id]);

        return $coment = $query->fetch(PDO::FETCH_OBJ);
    }

    // --------- INSERTS

    function insert($params)
    {      
        $query = $this->db->prepare('
                    INSERT INTO query_prop (localidad, 
                                            partido, 
                                            id_location, 
                                            tipo,
                                            m2cub, 
                                            m2tot, 
                                            rooms, 
                                            bedrooms, 
                                            parking, 
                                            parrilla, 
                                            pool, 
                                            is_country, 
                                            id_country, 
                                            new_contry, 
                                            address, 
                                            cant_casos, 
                                            value,
                                            search_round,
                                            date,
                                            hour) 
                    VALUES( :localidad, 
                            :partido, 
                            :id_location, 
                            :tipo,
                            :m2cub, 
                            :m2tot, 
                            :rooms, 
                            :bedrooms, 
                            :parking, 
                            :parrilla, 
                            :pool, 
                            :is_country, 
                            :id_country, 
                            :new_contry, 
                            :address, 
                            :incidencias, 
                            :value,
                            :search_round, 
                            :date,
                            :hour)');
        
        if($params['is_country'] == 1)
            $id_country = $params['id_country'];
        else    
        $id_country = null;
        $values = array(
                            ':localidad' => $params['localidad'], 
                            ':partido' => $params['partido'], 
                            ':id_location' => $params['id_loc'], 
                            ':tipo' => $params['tipo'],
                            ':m2cub' => $params['m2cub'], 
                            ':m2tot' => $params['m2tot'], 
                            ':rooms' => $params['rooms'], 
                            ':bedrooms' => $params['bedrooms'], 
                            ':parking' => $params['parking'], 
                            ':parrilla' => $params['parrilla'], 
                            ':pool' => $params['pool'], 
                            ':is_country' => $params['is_country'], 
                            ':id_country' => $id_country, 
                            ':new_contry' => $params['new_country'], 
                            ':address' => $params['address'], 
                            ':incidencias' => $params['incidencias'], 
                            ':value' => $params['value'],
                            ':search_round' => $params['search_round'], 
                            ':date' => $params['date'],
                            ':hour' => $params['hour']
                        );

        $query->execute($values);

        return $this->db->lastInsertId();
    }
}
           