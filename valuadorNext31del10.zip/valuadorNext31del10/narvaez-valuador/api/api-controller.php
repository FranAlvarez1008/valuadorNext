<?php

require_once ('./api/api-view.php');
require_once ('./api/location-model.php');
require_once ('./api/country-model.php');
require_once ('./api/props-model.php');
require_once ('./api/query-model.php');

class ApiController
{

    private $view;
    private $modelLocation;
    private $modelCountry;
    private $RATIO_M2CUB;
    private $RATIO_M2TOT;
    private $modelProps;
    private $modelQuery;


    function __construct()
    {
        $this->modelLocation = new LocationModel();
        $this->modelCountry = new CountryModel();
        $this->modelProps = new PropsModel();
        $this->modelQuery = new QueryModel();
        $this->view = new ApiView();
        $this->modelQuery = new QueryModel();
        $this->RATIO_M2CUB = 0.14;
        $this->RATIO_M2TOT = 0.14;
        date_default_timezone_set('America/Buenos_Aires');
    }

    function getProps($args = null)
    {
        //-----> 1° SEARCH con todos los filtros
        $args['search_round'] = 1;
        $args['amenities'] = true;
        $args['fullMeters'] = true;
        $props = $this->modelProps->getProp($args);

        //-----> 2° SEARCH sin comodities
        if(count($props) == 0){
            $args['search_round'] = 2;
            $args['amenities'] = false;
            $props = $this->modelProps->getProp($args);
        }

        //-----> 3° SEARCH sin m2 cubiertos (solo m2tot)
        if(count($props) == 0){
            $args['search_round'] = 3;
            $args['fullMeters'] = false;
            $props = $this->modelProps->getProp($args);
        }
        
        $value = 0;
        if(count($props) != 0)
            $value = $this->calculateValue($props);
        
        $args['value'] = (int)$value;
        $args['incidencias'] = count($props);

        //////////////////////////////// Insert Query
        $this->registerQuery($args);

        return $args;
    }

    function getPropsInterno()
    {
        // obtener los params GET
        $args = $this->obtainParams();

        //////////////////////////////// Filters
        //-----> 1° SEARCH con todos los filtros
        $args['search_round'] = 1;
        $args['amenities'] = true;
        $args['fullMeters'] = true;
        $props = $this->modelProps->getProp($args);

        //-----> 2° SEARCH sin comodities
        if(count($props) == 0){
            $args['search_round'] = 2;
            $args['amenities'] = false;
            $props = $this->modelProps->getProp($args);
        }

        //-----> 3° SEARCH sin m2 cubiertos (solo m2tot)
        if(count($props) == 0){
        $args['search_round'] = 3;
        $args['fullMeters'] = false;
        $props = $this->modelProps->getProp($args);
        }

        // prepare response
        $meta = array(
            'casos'         => sizeof($props),
            'search_round'  => $args['search_round']
        );
        $response = array(
            'meta'  => $meta,
            'data'  => $props,
        );

        //////////////////////////////// Response HTTP
        // $this->view->response($props, 200);
        $this->view->response($response, 200);

    }

    function calculateValue($props){
        // prom ponderados
        $sumMax = 0;
        $sumMin = 0;
        $countMax = 0;
        $countMin = 0;
        $size = sizeof($props);
        
        if($size==2)
            return ($props[1]->price*7 + $props[0]->price*3)/10;
        elseif($size==1)
            return $props[0]->price;

        if($size%2 == 0)
            $middle = $size/2;
        else
            $middle = ceil($size/2)-1;

        for($i = $middle; $i < $size; $i++){
            $sumMax += $props[$i]->price;
            $countMax += 1;
        }
        for($i = 0; $i < $middle; $i++){
            $sumMin += $props[$i]->price;
            $countMin += 1;
        }

        $promMax = $sumMax/$countMax;
        $promMin = $sumMin/$countMin;
        $promPonderado = ($promMax*7+$promMin*3)/10;
        return $promPonderado;
    }

    function registerQuery($args){
        // prepare params
        $args['date'] = date("Y-m-d");
        $args['hour'] = date('H:i:s');

        if($args['rooms'] == 'true'){
            $args['rooms'] = $args['cant'];
            $args['bedrooms'] = 0;
        }else{
            $args['bedrooms'] = $args['cant'];
            $args['rooms'] = 0;
        }

        // insert query
        $this->modelQuery->insert($args);
    }

    function searchPartido()
    {
        if (isset($_GET['partido'])) {
            $partido = $_GET['partido'];
            $partido = $this->modelLocation->searchPartido($partido);
            $this->view->response($partido, 200);
        } else {
            $partido = null;
            $this->view->response($partido, 400);
        }
    }

    function searchLocation()
    {
        if (isset($_GET['partido'])) {
            $partido = $_GET['partido'];
        } else {
            $partido = null;
        }
        $location = $this->modelLocation->searchLocation($partido);
        $this->view->response($location, 200);

    }
    function searchCountry()
    {
        if (isset($_GET['partido'])) {
            $partido = $_GET['partido'];
            $barrios = $this->modelCountry->getCountries($partido);
            $this->view->response($barrios, 200);
        } else {
            $partido = null;
            $this->view->response($partido, 400);
        }
    }
    function obtainParams(){
        if (isset($_GET['id_loc'])) {
                $id_loc = $_GET['id_loc'];
            } else {
                $id_loc = NULL;
            }
        if (isset($_GET['tipo'])) {
                $tipo = $_GET['tipo'];
            } else {
                $tipo = NULL;
            }
        if (isset($_GET['is_country'])) {
                $is_country = $_GET['is_country'];
            } else {
                $is_country = NULL;
            }
        if (isset($_GET['m2cub'])) {
                $m2cub = $_GET['m2cub'];
            } else {
                $m2cub = '';
            }
        if (isset($_GET['m2tot'])) {
                $m2tot = $_GET['m2tot'];
            } else {
                $m2tot = NULL;
            }
        if (isset($_GET['cant'])) {
                $cant = $_GET['cant'];
            } else {
                $cant = NULL;
            }
        if (isset($_GET['rooms'])) {
                $rooms = $_GET['rooms'];
            } else {
                $rooms = NULL;
            }
        if (isset($_GET['bedrooms'])) {
                $bedrooms = $_GET['bedrooms'];
            } else {
                $bedrooms = NULL;
            }  
        if (isset($_GET['partido'])) {
                $partido = $_GET['partido'];
            } else {
                $partido = NULL;
            }  
        if (isset($_GET['parrilla'])) {
                $parrilla = $_GET['parrilla'];
            } else {
                $parrilla = NULL;
            }
        if (isset($_GET['pool'])) {
                $pool = $_GET['pool'];
            } else {
                $pool = NULL;
            }  
        if (isset($_GET['parking'])) {
                $parking = $_GET['parking'];
            } else {
                $parking = NULL;
            }  
        if (isset($_GET['localidad'])) {
                $localidad = $_GET['localidad'];
            } else {
                $localidad = NULL;
            }  
        if (isset($_GET['id_country'])) {
                $id_country = $_GET['id_country'];
            } else {
                $id_country = NULL;
            }  
        if (isset($_GET['new_country'])) {
                $new_country = $_GET['new_country'];
            } else {
                $new_country = NULL;
            }  
        if (isset($_GET['address'])) {
                $address = $_GET['address'];
            } else {
                $address = NULL;
            }  
        
        $args['parking'] = $parking;
        $args['pool'] = $pool;
        $args['parrilla'] = $parrilla;
        $args['id_loc'] = $id_loc;
        $args['partido'] = $partido;
        $args['tipo'] = $tipo;
        $args['is_country'] = $is_country;
        $args['m2cub'] = $m2cub;
        $args['m2tot'] = $m2tot;
        $args['cant'] = $cant;
        $args['rooms'] = $rooms;
        $args['bedrooms'] = $bedrooms;
        $args['ratio_m2cub'] = $this->RATIO_M2CUB;
        $args['ratio_m2tot'] = $this->RATIO_M2TOT;
        $args['localidad'] = $localidad;
        $args['id_country'] = $id_country;
        $args['new_country'] = $new_country;
        $args['address'] = $address;

        return $args;
    }
}