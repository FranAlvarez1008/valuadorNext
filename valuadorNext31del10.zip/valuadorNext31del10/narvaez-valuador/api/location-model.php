<?php

class LocationModel
{
    private $db;

    public function __construct()
    {
        $this->db = new PDO('mysql:host=mysql.narvaez.com.ar;' . 'dbname=valuador;charset=utf8', 'valuador', 'DeFrGt&22');
    }

    //----------- SEARCH PARTIDO

    function searchPartido($name)
    {
        $query = $this->db->prepare(
            "SELECT DISTINCT partido 
            FROM `location` 
            WHERE partido LIKE ?
            ORDER BY partido ASC"
        );
        $query->execute([$name]);
        // $query->execute();

        return $items = $query->fetchAll(PDO::FETCH_OBJ);
    }
    function searchLocation($name)
    {
        $query = $this->db->prepare(
            "SELECT DISTINCT * 
            FROM `location` 
            WHERE partido LIKE ?
            ORDER BY localidad ASC"
        );
        $query->execute([$name]);

        return $items = $query->fetchAll(PDO::FETCH_OBJ);
    }
    function getLocationById($id)
    {
        $query = $this->db->prepare(
            "SELECT * 
            FROM `location` 
            WHERE id_location LIKE ?"
        );
        $query->execute([$id]);

        return $query->fetch(PDO::FETCH_OBJ);
    }

    function getLocationCountry($id)
    {
        $location = $this->getLocationById($id);
        
        $query = $this->db->prepare(
            "SELECT * 
            FROM `location` 
            WHERE partido LIKE ?
            AND localidad = 'barrio privado'"
        );
        $query->execute([$location->partido]);

        return $query->fetch(PDO::FETCH_OBJ);
    }

}
           