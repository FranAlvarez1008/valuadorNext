<?php

class CountryModel
{
    private $db;

    public function __construct()
    {
        // $this->db = new PDO('mysql:host=localhost;' . 'dbname=valuador;charset=utf8', 'root', '');
        $this->db = new PDO('mysql:host=mysql.narvaez.com.ar;' . 'dbname=valuador;charset=utf8', 'valuador', 'DeFrGt&22');
    }

    //----------- GET ALL

    function getCountries($partido = null)
    {
        if(is_null($partido))
            return null;

        $query = $this->db->prepare(
            'SELECT *
            FROM country
            WHERE partido = ? 
            ORDER BY localidad'
        );
        $query->execute([strtoupper($partido)]);

        return $items = $query->fetchAll(PDO::FETCH_OBJ);
    }

    function gerCountryById($id){
        $query = $this->db->prepare(
            'SELECT *
            FROM country
            WHERE id_country = ?'
        );
        $query->execute([$id]);

        return $items = $query->fetch(PDO::FETCH_OBJ);

    }


}
           