<?php

class PropsModel
{
    private $db;

    public function __construct()
    {
        // $this->db = new PDO('mysql:host=localhost;' . 'dbname=valuador;charset=utf8', 'root', '');
        $this->db = new PDO('mysql:host=mysql.narvaez.com.ar;' . 'dbname=valuador;charset=utf8', 'valuador', 'DeFrGt&22');

    }

    //----------- GET ALL

    function getProp($args)
    {
        $id_loc = $args['id_loc'];
        $is_country = $args['is_country'];
        $id_country = $args['id_country'];
        $m2tot = $args['m2tot'];
        $m2cub = $args['m2cub'];
        $ratio_m2cub = $args['ratio_m2cub'];
        $ratio_m2tot = $args['ratio_m2tot'];
        $rooms = $args['rooms'];
        $cant = $args['cant'];
        $tipo = $args['tipo'];
        $parking = $args['parking'];
        $pool = $args['pool'];
        $parrilla = $args['parrilla'];
        $amenities = $args['amenities'];
        $fullMeters = $args['fullMeters'];

        // tipo de propiedad
        if($tipo == 'casa')
        {
            $tabla = 'FROM casa c
            ';
            $query = 'SELECT c.id_casa,
            ';
        }
        elseif($tipo == 'ph')
        {
            $tabla = 'FROM ph c
            ';
            $query = 'SELECT c.id_ph,
            ';
        }
        elseif($tipo == 'dpto')
        {
            $tabla = 'FROM dpto c
            ';
            $query = 'SELECT c.id_dpto,
            ';
        }
        elseif ($tipo == 'lote') // si es lote la logica est en otra funsion
        {
            return $this->loteSQL($args);
            die();
        }

        $m2cubMIN = $m2cub*(1-$ratio_m2cub);
        $m2cubMAX = $m2cub*(1+$ratio_m2cub);
        $m2totMIN = $m2tot*(1-$ratio_m2tot);
        $m2totMAX = $m2tot*(1+$ratio_m2tot);

        $query .=  'c.url,
                    c.price,
                    c.location,
                    l.localidad,
                    l.partido,
                    l.zona,
                    c.m2cub,
                    c.m2tot,
                    c.rooms,
                    c.bedrooms,
                    c.bathrooms,
                    c.parking,
                    c.parrilla,
                    c.pool,
                    c.gym,
                    c.is_new,
                    c.is_country
                    ';

        $query .= $tabla;

        $query .='
        JOIN location l ON c.id_location = l.id_location
        ';

        // filter only by total surface square meters
        if($fullMeters){
            $query .='
            WHERE c.m2cub BETWEEN :m2cubMIN AND :m2cubMAX
            AND c.m2tot BETWEEN :m2totMIN AND :m2totMAX
            ';
        } else {
            $query .='
            AND c.m2tot BETWEEN :m2totMIN AND :m2totMAX
            ';
        }

        // filter by comodities
        if($amenities){

            // parking filter
            if($parking == "on"){
                $query .='
                AND c.parking > 0
                ';
                $query .=' ';
            }else{
                $query .='
                AND c.parking = 0
                ';
                $query .=' ';
            }

            // pool filter
            if($pool == "on"){
                $query .='
                AND c.pool = 1
                ';
                $query .=' ';
            }else{
                $query .='
                AND c.pool = 0
                ';
                $query .=' ';
            }

            // parrilla filter
            if($parrilla == "on"){
                $query .='
                AND c.parrilla = 1
                ';
                $query .=' ';
            }else{
                $query .='
                AND c.parrilla = 0
                ';
                $query .=' ';
            }
        }

        $query .=' ';

        
        // variables
        $values = array(
        ':m2totMIN'     => $m2totMIN,
        ':m2totMAX'     => $m2totMAX,
        ':cant'         => $cant
        );

        if($fullMeters){
            $values[':m2cubMIN'] = $m2cubMIN;
            $values[':m2cubMAX'] = $m2cubMAX;
   
        } 

        if($is_country == 1){
            $query .='AND c.is_country = 1'.' '.'AND c.id_country = :id_country';
            $values[':id_country'] = $id_country;
        } else {
            $query .= 'AND c.is_country = 0'.' '.'AND l.id_location = :id_loc';
            $values[':id_loc'] = $id_loc;
        }

        $query .= ' ';
        if($rooms == 'true'){
            $query .= 'AND c.rooms = :cant';
        } else{
            $query .= 'AND c.bedrooms = :cant ';
        }

        $query .=' '.'ORDER BY c.price ASC';

        $sql = $this->db->prepare($query);
        $sql->execute($values);

        return $sql->fetchAll(PDO::FETCH_OBJ);

        // DEBUG
        // $values[':pool'] = $pool;
        // $values[':parking'] = $parking;
        // $values[':parrilla'] = $parrilla;
        // $values[':rooms'] = $rooms;
        // $values[':sql'] = $query;
        // $values[':ratio_m2cub'] = $ratio_m2cub;
        // $values[':ratio_m2tot'] = $ratio_m2tot;
        // $values['tipo'] = $tipo;
        // return ($values);
    }








    private function loteSQL($args)
    {
        $id_loc = $args['id_loc'];
        $partido = $args['partido'];
        $is_country = $args['is_country'];
        $m2tot = $args['m2tot'];
        $ratio_m2tot = $args['ratio_m2tot'];
        $tipo = $args['tipo'];

        $m2totMIN = $m2tot*(1-$ratio_m2tot);
        $m2totMAX = $m2tot*(1+$ratio_m2tot);

        $query =  'SELECT   c.url,
                            c.id_lote,
                            c.price,
                            c.location,
                            l.localidad,
                            l.partido,
                            l.zona,
                            c.m2cub,
                            c.m2tot,
                            c.rooms,
                            c.bedrooms,
                            c.bathrooms,
                            c.parking,
                            c.parrilla,
                            c.pool,
                            c.gym,
                            c.is_new,
                            c.is_country
                            FROM lote c
                            JOIN location l ON c.id_location = l.id_location
                            WHERE c.m2tot BETWEEN :m2totMIN AND :m2totMAX
                            ';
        $values = array(
            ':m2totMIN'     => $m2totMIN,
            ':m2totMAX'     => $m2totMAX,
            );

        if($is_country == 1){
            $query .='AND c.is_country = 1'.' '.'AND l.partido = :partido';
            $values[':partido'] = $partido;
        } else {
            $query .= 'AND c.is_country = 0'.' '.'AND l.id_location = :id_loc';
            $values[':id_loc'] = $id_loc;
        }

        $query .=' '.'ORDER BY c.price ASC';

        $sql = $this->db->prepare($query);
        $sql->execute($values);

        return $sql->fetchAll(PDO::FETCH_OBJ);

        // DEBUG
        // $values[':sql'] = $query;
        // $values[':ratio_m2tot'] = $ratio_m2tot;
        // $values['tipo'] = $tipo;
        // return ($values);
    }
  }
