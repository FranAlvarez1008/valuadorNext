<?php

    if (isset($_POST['tipo'])) {
            $tipo = $_POST['tipo'];
        } else {
            $tipo = NULL;
        }
    if (isset($_POST['isCountry'])) {
            $is_country = $_POST['isCountry'];
        if($is_country == "")
                $is_country = NULL;
        } else {
            $is_country = NULL;
        }
    if (isset($_POST['m2cub'])) {
            $m2cub = $_POST['m2cub'];
        } else {
            $m2cub = '';
        }
    if (isset($_POST['m2tot'])) {
            $m2tot = $_POST['m2tot'];
        } else {
            $m2tot = NULL;
        }
    if (isset($_POST['cantidad'])) {
            $cant = $_POST['cantidad'];
        } else {
            $cant = NULL;
        }
    if (isset($_POST['rooms'])) {
            $rooms = $_POST['rooms'];
        } else {
            $rooms = NULL;
        }
    if (isset($_POST['partido'])) {
            $partido = $_POST['partido'];
        } else {
            $partido = NULL;
        }  
    if (isset($_POST['parrilla'])) {
            $parrilla = $_POST['parrilla'];
        } else {
            $parrilla = NULL;
        }
    if (isset($_POST['piletaHome'])) {
            $pool = $_POST['piletaHome'];
        } else {
            $pool = NULL;
        }  
    if (isset($_POST['cochera'])) {
            $parking = $_POST['cochera'];
        } else {
            $parking = NULL;
        }  
    if (isset($_POST['email'])) {
            $email = $_POST['email'];
        } else {
            $email = NULL;
        }  
    if (isset($_POST['tel'])) {
            $tel = $_POST['tel'];
        } else {
            $tel = NULL;
        } 
    if (isset($_POST['name'])) {
            $name = $_POST['name'];
        } else {
            $name = NULL;
        } 
    if (isset($_POST['apellido'])) {
            $lastname = $_POST['apellido'];
        } else {
            $lastname = NULL;
        }  
    if (isset($_POST['ipInput'])) {
            $ip = $_POST['ipInput'];
        } else {
            $ip = NULL;
        } 
    if (isset($_POST['otroCountry'])) {
            $otroCountry = $_POST['otroCountry'];
        } else {
            $otroCountry = NULL;
        }  
    if (isset($_POST['nombreBarrio'])) {
            $country = $_POST['nombreBarrio'];
        } else {
            $country = NULL;
        }  
    if (isset($_POST['address'])) {
            $address = $_POST['address'];
        } else {
            $address = NULL;
        }  
    if (isset($_POST['localidadId'])) {
            $localidad = $_POST['localidadId'];
        } else {
            $localidad = NULL;
        }  

    // DEBUG -------------------------------------
    // $args['parking'] = $parking;
    // $args['pool'] = $pool;
    // $args['parrilla'] = $parrilla;
    // $args['id_loc'] = $id_loc;
    // $args['partido'] = $partido;
    // $args['address'] = $address;
    // $args['tipo'] = $tipo;
    // $args['localidad'] = $localidad;
    // $args['is_country'] = $is_country;
    // $args['m2cub'] = $m2cub;
    // $args['m2tot'] = $m2tot;
    // $args['cant'] = $cant;
    // $args['rooms'] = $rooms;
    // $args['bedrooms'] = $bedrooms;
    // $args['email'] = $email;
    // $args['tel'] = $tel;
    // $args['otroCountry'] = $otroCountry;
    // $args['country'] = $country;
    // $args['value'] = $value;
    // echo('<br><br><br>');
    // foreach ($args as $key => $item) {
    //     echo('<ul>');
    //     echo('<li>'.$key.': '.$item.'</li>');
    //     echo('</ul>');
    // }
