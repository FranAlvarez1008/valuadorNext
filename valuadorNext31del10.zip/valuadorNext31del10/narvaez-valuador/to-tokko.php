<?php
    if($email != ""){
        
        $TOKEN = "57cb56cecd071cbcc7a3faeb064dd9fe178b01d9";
        $url_tokko = "http://www.tokkobroker.com/api/v1/webcontact/?key=".$TOKEN;
                
        $curl = curl_init($url_tokko);
        curl_setopt($curl, CURLOPT_URL, $url_tokko);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    
        $headers_tokko = array(
            "Accept: application/json",
            "Content-Type: application/json",
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers_tokko);
        $tags = array("solicita-tasador", "valuador");


        // $datos = array(
        //     "phone" => "2284602364",
        //     "email" => "tomas.cogliatti",
        //     "text" => "texto prueba",
        //     "tags" => $tags
        // );
        $datos = array(
            "name" => $name,
            "last_name" => $apellido,
            "phone" => $tel,
            "email" => $email,
            "text" => $msg,
            "tags" => $tags
        );
        
        // Codificar los datos como JSON y establecerlos como el cuerpo de la petición
        $objeto_json = json_encode($datos);
        // print_r($objeto_json);
    
        curl_setopt($curl, CURLOPT_POSTFIELDS, $objeto_json);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    
        // ejecuta el request HTTP
        $resp = curl_exec($curl);
        if ($resp === false)
            echo 'Error: ' . curl_error($curl);
        else
        
        // Cerrar el controlador de petición HTTP
        curl_close($curl);

    }
       
?>